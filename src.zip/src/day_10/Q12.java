package day_10;
/*
12. WAP to check Exception handling 
with method overriding. 
Means, If super class method don�t Declare exception 
then subclass overridden method can declare exception or not.
 */

class parent {
	public void m1() {
		System.out.println("Inside Parent");
	}
}

class child extends parent {
public void m1() throws ArithmeticException {
	System.out.println("Inside Child");
	}
}
public class Q12 {

	public static void main(String[] args) {
		child c = new child();
		try {
			c.m1();
		}
		
		catch (ArithmeticException e) {
			System.out.println("Inside Catch Block");
		}

		parent p = new child();
		try {
			p.m1();
		}
		
		catch (ArithmeticException e) {
			System.out.println("Inside Catch Block");
		}
	}

}
