package day_10;

import java.util.Scanner;
import java.util.regex.Pattern;

/*
6. Write a program to create custom exception called �Invalid Password�. 
Write a method which validates password entered by user? 
If password does not contain 
any digit throw InvalidPasswordException
 */

class Invalid_Password extends Exception {
	
	Invalid_Password() {
		super("1) Invalid_Password Constructor");
	}
	
	public String toString() {
		return "2) Invalid_Password toString";
	}
}
public class Q06 {
	static void m1(String str) throws Invalid_Password{
		if(str.matches("Mohit123")) {
			System.out.println("3) Valid Password");
			
		}
		else
			throw new Invalid_Password();
	}

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.print("Enter PassWord : ");
		String str= sc.next();
		
		try {
			m1(str);			
		}
		
		catch (Invalid_Password e) {
			System.out.println("4) Invalid_Password Catch Block");
			System.out.println(e.toString());
			System.out.println(e.getMessage());
		}
		
		System.out.println("5) Out of Try-Catch");

	}

}
