package day_10;
/*
Show in code how unchecked exception propagates
==============================================
Inside M3
Inside M2
Inside M1
/ by zero
java.lang.ArithmeticException: / by zero
	at day_10.Q08.m1(Q08.java:10)
	at day_10.Q08.m2(Q08.java:16)
	at day_10.Q08.m3(Q08.java:21)
	at day_10.Q08.m4(Q08.java:27)
	at day_10.Q08.main(Q08.java:39)
rest of the code...
===========================================
Inside M4
Inside M3
Inside M2
Inside M1
/ by zero
java.lang.ArithmeticException: / by zero
	at day_10.Q08.m1(Q08.java:24)
	at day_10.Q08.m2(Q08.java:30)
	at day_10.Q08.m3(Q08.java:35)
	at day_10.Q08.m4(Q08.java:42)
	at day_10.Q08.main(Q08.java:54)
rest of the code...

 */
public class Q08 {
	public static void m1() {
		System.out.println("Inside M1");
		int a=10;
		int b=0;
		System.out.println("Division : "+a/b);
		
		}
	
	public static void m2() {
		System.out.println("Inside M2");
		m1();
		
		}
	public static void m3() {
		System.out.println("Inside M3");
		m2();
		
		}
	public static void m4() {
		try
		{
		System.out.println("Inside M4");
		m3();
		}
		
		catch (ArithmeticException e)
		{
		System.out.println(e.getMessage());
		e.printStackTrace();
		}
	}
		//===============================================
		public static void main(String args[]){
		try {
			m4();
		}
		catch (Exception e)
		{
		System.out.println("Hello");
		System.out.println(e.getMessage());
		e.printStackTrace();
		}
		System.out.println("rest of the code...");
		}
}
