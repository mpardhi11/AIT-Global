package day_10;
/* WAP to catch multiple exceptions
Exception e
rest of the code
--------------------------
ArrayIndexOutOfBoundsException
rest of the code

 */
public class Q10 {

	public static void main(String[] args) {
		try{    
            String s="Mohit";
            char c=s.charAt(10);
            System.out.println(c);
           }    
           catch(ArithmeticException e)  
              {  
               System.out.println("ArithmeticException e");  
              }    
           catch(StringIndexOutOfBoundsException e)  
              {  
               System.out.println("ArrayIndexOutOfBoundsException");  
              }    
           catch(Exception e)  
              {  
               System.out.println("Exception e");  
              }             
           System.out.println("rest of the code");    

	}

}
