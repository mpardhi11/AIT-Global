package day_10;
/*
WAP where only try and finally is used.
==========================
finally {} is executed
Exception in thread "main" java.lang.ArithmeticException: / by zero
	at day_10.Q09.main(Q09.java:9)
==================================
2
finally {} is executed

 */
public class Q09 {

	public static void main(String[] args) {
		try {
			System.out.println(10/5);
		}
		
		finally {
			System.out.println("finally {} is executed");
		}

	}

}
