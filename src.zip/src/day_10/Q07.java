package day_10;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.SQLException;

/*
WAP to show checked exception and use multiple catch block with universal Exception handler.
 */
public class Q07 {
	public static void method() throws ClassNotFoundException, SQLException, FileNotFoundException {
	FileReader AAA = new FileReader("C:\\a.txt");
	
	}
	//===============================================
	public static void main(String args[]){
	try
	{
	method();
	}
	
	catch (ClassNotFoundException e)
	{
	e.printStackTrace();
	System.out.println(e.getMessage());
	}
	catch (SQLException e)
	{
	e.printStackTrace();
	System.out.println(e.getMessage());
	}
	catch (FileNotFoundException e)
	{
	e.printStackTrace();
	System.out.println(e.getMessage());
	}
	catch (Exception e)
	{
	e.printStackTrace();
	System.out.println(e.getMessage());
	}
	
	System.out.println("rest of the code...");
	}
	}
