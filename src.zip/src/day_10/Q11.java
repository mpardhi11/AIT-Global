package day_10;
/*
WAP to throw exception still finally should get executed

Line 1 :: 
2

Line 3 :: finally {} is executed 

Exception in thread "main" java.lang.ArithmeticException: 
Line 2  :: Arithmetic :_-_-_-_: Exception 

	at day_10.Q11.main(Q11.java:10)

 */
public class Q11 {

	public static void main(String[] args) {
		try {
			//System.out.println("Line 1 :: \n"+10/0);
			int a=10,b=0;
			
			if(b==0) {
				throw new ArithmeticException("\nLine 2  :: Arithmetic :_-_-_-_: Exception \n");
			}
			
			else 
				System.out.println("----------------");
			//
		}
		
		catch(ArithmeticException e) {
			System.out.println("HelLLLO");
		}
		finally {
			System.out.println("\nLine 3 :: finally {} is executed \n");
		}
		System.out.println("Rest of program");
		
		

	}

}
