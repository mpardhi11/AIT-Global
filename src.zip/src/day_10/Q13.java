package day_10;
/*
 13. WAP to show the scenario in which 
 number-format exception is generated and handle this Exception.
 -----------------------------
 Value of a : 145
string is present

 */
public class Q13 {

	public static void main(String[] args) {
	      try {  
	            int a = Integer.parseInt("145");
	            System.out.println("Value of a : "+a);
	        }
	        
	        catch(NumberFormatException e){  
	       System.out.println("string is present");  
	   } 
		
		try {  
            int b = Integer.parseInt("Mohit");  
        }
        
        catch(NumberFormatException e){  
       System.out.println("string is present");  
   }  

	}

}
