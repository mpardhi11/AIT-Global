package day_16_HashMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/* 4. Create a Map which contain Integer as key and 
 * Another Map as Value 
 * another Map Contain Emp as Key and Integer as value 
 * Print the Map using Iterator. 
 * ======================================================
 * */
public class Q_04 {

	public static void main(String[] args) {
		HashMap<Emp2, Integer> hm1= new HashMap<>();
		HashMap<Integer, HashMap<Emp2, Integer>> hm2= new HashMap<>();
		
		hm1.put(new Emp2(01, "Mohit", 123.45f), 1);
		hm1.put(new Emp2(02, "Ram", 13.45f), 2);
		hm1.put(new Emp2(01, "Mohit", 23.45f), 3);
		hm1.put(new Emp2(03, "Sham", 523.45f), 4);
		hm1.put(new Emp2(04, "Ram", 283.45f), 5);
		//hm1.g
		
		//System.out.println(hm1);
		Integer x=1;
		hm2.put(x, hm1);
		hm2.put((x+1), hm1);
		
		Set<Entry<Integer, HashMap<Emp2, Integer>>> s=hm2.entrySet();
		Iterator<Entry<Integer, HashMap<Emp2, Integer>>> itr=s.iterator();
		while(itr.hasNext()) {
			Entry<Integer, HashMap<Emp2, Integer>> e=itr.next();
			//e.getValue();
			System.out.println("Key : "+e.getKey()+" Values : "+e.getValue());
			//System.out.println(xx.getKey()+" "+xx.getValue());
		}

	}

}
