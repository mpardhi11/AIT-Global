package day_16_HashMap;

public class Order {
	String address,city,state;
	Integer pin;
@Override
	public String toString() {
		return "Order [address=" + address + ", city=" + city + ", state=" + state + ", pin=" + pin + "]";
	}
	public Order(String address,String city, String state, Integer pin) {
		super();
		this.address = address;
		this.city = city;
		this.state = state;
		this.pin = pin;
	}
	
	
	
	
	
	
	
	
	
}
