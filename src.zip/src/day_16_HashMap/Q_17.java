package day_16_HashMap;

import java.util.ArrayList;
import java.util.TreeMap;

/* 
17. An arraylist has strings "A+2" , "B+12" , "D+4", "DD+5" and so on. 
Create a treemap which has alphabets as keys and integers as values. 

It should be sorted in descending order of keys. 
==================================================
{A=2, B=12, D=14}

*/
public class Q_17 {

	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<>();
		TreeMap<Character, Integer> tm=new TreeMap<>();
		al.add("A 2");
		al.add("B 12");
		al.add("D 4");
		al.add("DD 5");
		
		for(String s : al) {
			String[] sArr=s.split(" ");
			Integer x=Integer.parseInt(sArr[1]);
			for(int i=0;i<sArr[0].length();i++) {
				if (tm.containsKey(sArr[0].charAt(i))) {
					Integer old_Value=tm.get(sArr[0].charAt(i));
					Integer new_Value=(old_Value+x);
					tm.put(sArr[0].charAt(i),new_Value);
				}
				else {
					tm.put(sArr[0].charAt(i), x);
				}
			}
			
		}	
		System.out.println(tm);

}
}
