package day_16_HashMap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.Set;
import java.util.TreeMap;

/* 
3. Create a Linkedhashmap which contains Emp is keys and 
Emp id is values.
But Map does not contain Same id as key for Emp Object. 

7. Display LinkedHashMap created in Q3 in access order of entries.
======================================================



*/
public class Q_03 {

	public static void main(String[] args) {
		TreeMap<Integer, Emp> tm=new TreeMap<>();
		ArrayList<Emp> al=new ArrayList<>();
		
		al.add(new Emp(1, "Mohit", 123.45f));
		al.add(new Emp(2, "Ram", 12.45f));
		al.add(new Emp(3, "Sham", 23.45f));
		al.add(new Emp(1, "Sam", 13.45f)); // ही  value replace झाली पाहिजे 
		al.add(new Emp(5, "Sammer", 123.5f));
		al.add(new Emp(6, "Chanky", 123.455f));
		
		LinkedHashMap<Emp, Integer> lhm=new LinkedHashMap<>(32, 0.75f, true);
		
		for(int i=0;i<al.size();i++) {
			Emp x=al.get(i);
			lhm.put(al.get(i), x.id);
		}
		Set<Entry<Emp, Integer>> set = lhm.entrySet();
		for(Entry<Emp, Integer> ee : set) {
			
			System.out.println("Emp ID : "+ee.getValue());
			System.out.println("\tEmp as Key : "+ee.getKey());
			System.out.println("//______________________________");
		}
		
		System.out.println("Displaying Access Order : ");
		//Entry<Emp, Integer> e=lhm.get(Emp (5, "Sammer", 123.5f));
		Integer x=lhm.get(al.get(2));
		set = lhm.entrySet();
		Iterator<Entry<Emp, Integer>> itr=set.iterator();
		while (itr.hasNext()) {
//			Entry<Emp, Integer> e=itr.next();
//			Emp xx=e.getKey();
//			Integer
			System.out.println(itr.next());
			
		}
		
		
		//NavigableMap<Emp, Integer> nm= new Navi
		
		

	}

}
