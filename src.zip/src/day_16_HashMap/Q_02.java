package day_16_HashMap;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Set;

/*
2. Create a Linkedhashmap<int,String> 
where key is integers 1 to 10 and 
string is number in words.
Remove entry for which number is divisible by 3.
======================================================
{1=One, 2=Two, 3=Three, 4=Four, 5=Five, 6=Six, 7=Seven, 8=Eight, 9=Nine, 10=Ten}
{1=One, 2=Two, 4=Four, 5=Five, 7=Seven, 8=Eight, 10=Ten}

 */
public class Q_02 {

	public static void main(String[] args) {
		LinkedHashMap<Integer,String> Linked_HM= new LinkedHashMap<>();
		
		Linked_HM.put(1, "One");
		Linked_HM.put(2, "Two");
		Linked_HM.put(3, "Three");
		Linked_HM.put(4, "Four");
		Linked_HM.put(5, "Five");
		Linked_HM.put(6, "Six");
		Linked_HM.put(7, "Seven");
		Linked_HM.put(8, "Eight");
		Linked_HM.put(9, "Nine");
		Linked_HM.put(10, "Ten");
		System.out.println(Linked_HM);

		Set<Integer> s= Linked_HM.keySet();
		Iterator<Integer> itr=s.iterator();
		
		while(itr.hasNext()) {
			int x=itr.next();
			if(x%3==0)
				itr.remove();
		}
		
		System.out.println(Linked_HM);
//		for(int i=0;i<s.size();i++) {
//			int x=s
//		}

	}

}
