package day_16_HashMap;

import java.util.HashMap;
import java.util.TreeMap;

/* 5. Accept string from user. 
 * Create a map which has key as character in string and 
 * value as number of occurances of that character in string. 
 * E.g. given string is �pizzapan� map will be <p,2>,<i , 1>,<z, 2>,<a,2>,<n,1> 
 * ==========================================================
 * Using TreeMap : {a=2, i=1, n=1, p=2, z=2}
Using HashMap : {p=2, a=2, i=1, z=2, n=1}

 * */
public class Q_05 {

	public static void main(String[] args) {
		String s="pizzapan";
		
		TreeMap<Character, Integer> tm= new TreeMap<>();
		HashMap<Character,Integer> hm=new HashMap<>();
		//Scanner sc=new Scanner(System.in);
		//String s=sc.next();
		
		for(int i=0 ; i<s.length() ; i++)
		{
			char c=s.charAt(i);
			if(tm.containsKey(c) && hm.containsKey(c))
			{
				int count_value_tm=tm.get(c);
				int count_value_hm=hm.get(c);
				tm.put(c, count_value_tm+1);
				hm.put(c, count_value_hm+1);
			}
			else 
				{
				tm.put(c, 1);
				hm.put(c, 1);
				}
				
		}
		System.out.println("Using TreeMap : "+tm);
		System.out.println("Using HashMap : "+hm);


}
}
