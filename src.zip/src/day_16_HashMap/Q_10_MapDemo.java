package day_16_HashMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
/*
tasty
laddu
3

 */
public class Q_10_MapDemo {
		public static void main(String[] args) {
		HashMap<Integer,String> map = new LinkedHashMap();
		map.put(1 , "Jilebi");
		map.put(2,"Modak");
		map.put(3, "laddu");
		
		if(map.put(2, "Barfi") == null )
		System.out.println("yummy");
		else
		System.out.println("tasty"); //
		
		System.out.println(map.put(3, "Halwa")); // laddu
		
		System.out.println(map.size()); //3
		
}
}
