package day_16_HashMap;

import java.util.Comparator;

public class custId implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		if (o1.custid>o2.custid)
		return 1;
		else if (o1.custid<o2.custid)
		return -1;
		else
		return 0;
		
		
	}

}
