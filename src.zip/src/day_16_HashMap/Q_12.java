package day_16_HashMap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NavigableMap;
import java.util.NavigableSet;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map.Entry;

/* 
12.Create Customer class with custid,custName, mobile fields. 
Create Order class with ordered,orderDetails fields.

Create TreeMap with 
customer as key and 
Order as value .

it should be sorted according to custId in ascending order.

13. Add TreeMap created in Q12 in other TreeMap 
which should be sorted by custID in descending order.

15. Write a code to traverse a treemap created in Q12 using three different ways.

==================================================================
Customer id ,name , mobile
5
Mohit
784584584
Address, city, state, pin
aa
pune
maha
445411
Customer id ,name , mobile
1101
Mohit
784584584
Address, city, state, pin
aa
pune
maha
445411
Customer id ,name , mobile
66
Mohit
784584584
Address, city, state, pin
aa
pune
maha
445411
Customer id ,name , mobile
2
sham
78451587
Address, city, state, pin
aa
pune
maha
445411
Customer id ,name , mobile
99
zebra
78451548
Address, city, state, pin
aa
pune
maha
445411
//______________________________________________
Customer id : 2 Customer Namesham Customer Mobile : 78451587
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 5 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 66 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 99 Customer Namezebra Customer Mobile : 78451548
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 1101 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 1101 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 99 Customer Namezebra Customer Mobile : 78451548
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 66 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 5 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
//______________________________________________
Customer id : 2 Customer Namesham Customer Mobile : 78451587
Address : aa Citypune Pin : 445411
//______________________________________________
//___________________XXXXXXX____________________
NavigableSet<Customer> ns=(NavigableSet<Customer>) tm.keySet()
Customer id : 2 Customer Namesham Customer Mobile : 78451587
Address : aa Citypune Pin : 445411
Customer id : 5 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
Customer id : 66 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
Customer id : 99 Customer Namezebra Customer Mobile : 78451548
Address : aa Citypune Pin : 445411
Customer id : 1101 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411
Search-Search-Search-Search-Search-Search-Search-Search-Search-
Customer id : 1101 Customer NameMohit Customer Mobile : 784584584
Address : aa Citypune Pin : 445411

*/
public class Q_12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);

		TreeMap<Customer, Order> tm=new TreeMap<>(new custId());
		
		
		
		for(int i=0;i<5;i++) {
			System.out.println("Customer id ,name , mobile");

			Customer c= new Customer(sc.nextInt(), sc.next(), sc.next());
			System.out.println("Address, city, state, pin");
			String l1=sc.next();
			String l2=sc.next();
			String l3=sc.next();
			Integer l4=(Integer) sc.nextInt();
			Order o= new Order(l1,l2,l3,l4);
			
			tm.put(c, o);
			
		}
		//System.out.println(tm);
		Set<Entry<Customer, Order>> s=tm.entrySet();
		Iterator<Entry<Customer, Order>> itr=s.iterator();
		
		while(itr.hasNext()) {
			Entry<Customer, Order> ee= itr.next();
			Customer c=ee.getKey();
			Order o=ee.getValue();
			System.out.println("//______________________________________________");
			System.out.println("Customer id : "+c.custid+" Customer Name"+c.custName+" Customer Mobile : "+c.mobile);
			System.out.println("Address : "+o.address+" City"+o.city+" Pin : "+o.pin);
			System.out.println("//______________________________________________");
			System.out.println("//___________________XXXXXXX____________________");
		}
		NavigableMap<Customer, Order> nm = tm.descendingMap();

		//TreeMap<Customer, Order> tm2=new TreeMap<>(nm);
		s=nm.entrySet();
		itr=s.iterator();
		
		while(itr.hasNext()) {
			Entry<Customer, Order> ee= itr.next();
			Customer c=ee.getKey();
			Order o=ee.getValue();
			System.out.println("//______________________________________________");
			System.out.println("Customer id : "+c.custid+" Customer Name"+c.custName+" Customer Mobile : "+c.mobile);
			System.out.println("Address : "+o.address+" City"+o.city+" Pin : "+o.pin);
			System.out.println("//______________________________________________");
			System.out.println("//___________________XXXXXXX____________________");
		}
		
		
		//Entry<Customer, Order> ent;
		NavigableSet<Customer> ns=(NavigableSet<Customer>) tm.keySet();
		Iterator<Customer> itr2=ns.iterator();
		System.out.println("NavigableSet<Customer> ns=(NavigableSet<Customer>) tm.keySet()");
		for(Customer c: ns) {
			System.out.println("Customer id : "+c.custid+" Customer Name"+c.custName+" Customer Mobile : "+c.mobile);
			Order o=tm.get(c);
			System.out.println("Address : "+o.address+" City"+o.city+" Pin : "+o.pin);
		}
		
		ns=(NavigableSet<Customer>) tm.keySet();
		itr2=ns.iterator();
		System.out.println("Search-Search-Search-Search-Search-Search-Search-Search-Search-");
		for(Customer c: ns) {
			if(c.custid==1101) {
				System.out.println("Customer id : "+c.custid+" Customer Name"+c.custName+" Customer Mobile : "+c.mobile);
				Order o=tm.get(c);
				System.out.println("Address : "+o.address+" City"+o.city+" Pin : "+o.pin);
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
