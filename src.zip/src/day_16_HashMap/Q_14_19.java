package day_16_HashMap;

import java.util.NavigableMap;
import java.util.SortedMap;
import java.util.TreeMap;
/*
14. Create TreeMap with month number as key and month name as value. Means it should contain entries like { 1=January,2=February....}
From this treemap get portion of Map whose month numbers are between 3 to 7 including both 3 and 7.

19. Display treemap created in q14 in reverse order.

===========================================
Initial of map is :{1=jan, 2=feb, 3=mar, 4=april, 5=may, 6=june, 7=july, 8=august, 9=sept, 10=oct, 11=nov, 12=dec}
After sorted {3=mar, 4=april, 5=may, 6=june, 7=july, 8=august, 9=sept}
Reverse Order
{12=dec, 11=nov, 10=oct, 9=sept, 8=august, 7=july, 6=june, 5=may, 4=april, 3=mar, 2=feb, 1=jan}

 */
public class Q_14_19 {
	public static void main(String[] args) 
	{
		TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
		
		tm.put(1, "jan");
		tm.put(2, "feb");
		tm.put(3, "mar");
		tm.put(4, "april");
		tm.put(5, "may");
		tm.put(6, "june");
		tm.put(7, "july");
		tm.put(8, "august");
		tm.put(9, "sept");
		tm.put(10, "oct");
		tm.put(11, "nov");
		tm.put(12, "dec");
		
		System.out.println("Initial of map is :"+tm);
		SortedMap<Integer, String> sm2 = tm.subMap(3, true, 9, true);
		System.out.println("After sorted "+sm2);
		
		System.out.println("Reverse Order");
		NavigableMap<Integer, String > np = tm.descendingMap();
		System.out.println(np);
	}}
