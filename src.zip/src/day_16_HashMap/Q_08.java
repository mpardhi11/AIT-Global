package day_16_HashMap;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

/* 8. Create LinkedHashMap which will have 
 * Student type key object and 
 * arraylist of course names for which Student admitted ie, 
 * like LinkedHashMap<Stuednt,ArrayList<Course>> . 
 * display list of courses for which student has enrolled. 
 * ========================================================
 * ID, Name
01 Mohit

[Mohit] You Want this course : Java true
[Mohit] You Want this course : C++ true
[Mohit] You Want this course : C true
[Mohit] You Want this course : Html true
[Mohit] You Want this course : Css true
ID, Name
02 Raju

[Raju] You Want this course : Java false
[Raju] You Want this course : C++ true
[Raju] You Want this course : C false
[Raju] You Want this course : Html true
[Raju] You Want this course : Css false
ID, Name
03 Ajax

[Ajax] You Want this course : Java false
[Ajax] You Want this course : C++ true
[Ajax] You Want this course : C false
[Ajax] You Want this course : Html false
[Ajax] You Want this course : Css false
{Stuednt [s_ID=1, s_Name=Mohit]=[Java, C++, C, Html, Css], Stuednt [s_ID=2, s_Name=Raju]=[C++, Html], Stuednt [s_ID=3, s_Name=Ajax]=[C++]}
//====================================
//====================================
//====================================
Student ID : 1 Named : Mohit Purcahsed : [Java, C++, C, Html, Css]
Student ID : 2 Named : Raju Purcahsed : [C++, Html]
Student ID : 3 Named : Ajax Purcahsed : [C++]

*/
public class Q_08 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		LinkedHashMap<Stuednt,ArrayList<String>> lhm=new LinkedHashMap<>();
		
		for(int i=0;i<3;i++) {
			ArrayList<String> Course= new ArrayList<>();
			String[] sArr= {"Java","C++","C","Html","Css"};
			System.out.println("ID, Name");
			int x=sc.nextInt();
			String s= sc.next();
			System.out.println("");
			for(int j=0;j<sArr.length;j++) {
				System.out.print("["+s+"]"+" You Want this course : "+sArr[j]+" ");
				if(sc.nextBoolean())
					Course.add(sArr[j]);
			}
			
			Stuednt Z= new Stuednt(x, s);
			lhm.put(Z, Course);
			
		}

		System.out.println(lhm);
		System.out.println("//====================================");
		System.out.println("//====================================");
		System.out.println("//====================================");
		
		Set<Entry<Stuednt,ArrayList<String>>> s=lhm.entrySet();
		Iterator<Entry<Stuednt,ArrayList<String>>> itr=s.iterator();
		
		while(itr.hasNext()) {
			Entry<Stuednt,ArrayList<String>> ee= itr.next();
			Stuednt z=ee.getKey();
			System.out.println("Student ID : "+z.s_ID+" Named : "+z.s_Name+" Purcahsed : "+ee.getValue());
			//System.out.println(ee.getValue());
		}
	}

}
