package day_16_HashMap;

public class Customer {
	int custid;
	String custName, mobile;
	@Override
	public String toString() {
		return "Customer [custid=" + custid + ", custName=" + custName + ", mobile=" + mobile + "]";
	}
	public Customer(int custid, String custName, String mobile) {
		super();
		this.custid = custid;
		this.custName = custName;
		this.mobile = mobile;
	}
	
	
}
