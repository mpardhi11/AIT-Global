package day_16_HashMap;
import java.util.Objects;
import java.util.Scanner;

public class Stuednt {
int s_ID;
String s_Name;

public Stuednt(int s_ID, String s_Name) {
	super();
	this.s_ID = s_ID;
	this.s_Name = s_Name;
}


@Override
public String toString() {
	return "Stuednt [s_ID=" + s_ID + ", s_Name=" + s_Name + "]";
}


@Override
public int hashCode() {
	return Objects.hash(s_ID);
}


@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Stuednt other = (Stuednt) obj;
	return s_ID == other.s_ID;
}


}
