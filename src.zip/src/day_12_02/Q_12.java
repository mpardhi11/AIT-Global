package day_12_02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*
12WAP to create Emp (id, name, sal) object and add 2objects to ArrayList. Print and see both variable memory space is printed. This is because toString is not overridden but if you would have done this for Integer then beautiful output would have been printed.
13.Now override toString in Emp class and now print and see values are printed
14.WAP to print Emp whose salary is > 10000.
15.WAP to print Emp who have name "Sachin".
16. WAP to print Emp who have highest number of salary.
-----------------------------------------------------
Data has been Printing Using Loop---------------------

Emp [id=101, sal=25000, name=Mohit]
Emp [id=102, sal=5000, name=Sachin]
Emp [id=103, sal=15000, name=Ram]
Emp [id=104, sal=26500, name=Sumit]
Emp [id=105, sal=28000, name=Rohan]
//=========================================
14.WAP to print Emp whose salary is > 10000.
Emp [id=101, sal=25000, name=Mohit]
Emp [id=103, sal=15000, name=Ram]
Emp [id=104, sal=26500, name=Sumit]
Emp [id=105, sal=28000, name=Rohan]
//=========================================
15.WAP to print Emp who have name 'Sachin'
Emp [id=102, sal=5000, name=Sachin]
//============================================
16. WAP to print Emp who have highest number of salary. 
Emp [id=105, sal=28000, name=Rohan]
//============================================
//============================================
For Loop : Emp [id=105, sal=28000, name=Rohan]
For Loop : Emp [id=104, sal=26500, name=Sumit]
For Loop : Emp [id=101, sal=25000, name=Mohit]
For Loop : Emp [id=103, sal=15000, name=Ram]
For Loop : Emp [id=102, sal=5000, name=Sachin]

 */
class Emp implements Comparable<Emp>{
	int id,sal;
	String name;
	public Emp(int id, int sal, String name) {
		//super();
		this.id = id;
		this.sal = sal;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", sal=" + sal + ", name=" + name + "]";
	}
	@Override
	public int compareTo(Emp o) {
		if(this.sal>o.sal)
			return -1;
		else if(this.sal<o.sal)
			return 1;
		else
		return 0;
	}
}

public class Q_12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ArrayList<Emp> x= new ArrayList<>();
		
//		Emp[] w = new Emp[4];
//		for(int i=0;i<4;i++) {
//			System.out.println("Enter");
//				w[i]=new Emp(sc.nextInt(),sc.nextInt(),sc.next());
//			x.add(w[i]);
//		}
		
		x.add(new Emp(101, 25000, "Mohit"));
		x.add(new Emp(102, 5000, "Sachin"));
		x.add(new Emp(103, 15000, "Ram"));
		x.add(new Emp(104, 26500, "Sumit"));
		x.add(new Emp(105, 28000, "Rohan"));
		
		
		
//		System.out.println("Data has been Printed---------------------\n");
//		System.out.println(x);
		System.out.println("Data has been Printing Using Loop---------------------\n");
		for(int i=0;i<x.size();i++) {
			System.out.println(x.get(i));
		}
		
		System.out.println("//=========================================");
		System.out.println("14.WAP to print Emp whose salary is > 10000.");

		for(int i=0;i<x.size();i++) {
			Emp e= (Emp) x.get(i);
			if(e.sal>10000) {
				System.out.println(e.toString());
			}
		}
		System.out.println("//=========================================");
		System.out.println("15.WAP to print Emp who have name 'Sachin'");
		for(int i=0;i<x.size();i++) {
			Emp e= (Emp) x.get(i);
			if(e.name.equals("Sachin")) {
				System.out.println(e.toString());
			}
		}
		Collections.sort(x);
		System.out.println("//============================================");
		System.out.println("16. WAP to print Emp who have highest number of salary. ");
		System.out.println(x.get(0));
		
		System.out.println("//============================================");
		System.out.println("//============================================");
		for(int i=0;i<x.size();i++) {
			System.out.println("For Loop : "+x.get(i));
		}
		
		sc.close();
	}
}
