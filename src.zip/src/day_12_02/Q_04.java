package day_12_02;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

/* 
4. WAP to print all elements of ArrayList using -
-Iterator
-for loop
-for each
====================================
[0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
0	1	2	3	4	5	6	7	8	9	
[0, 1, 2, 3, 4, 5, 6, 7, 8]
==================
Vlaue : 8 Index : 7
Vlaue : 7 Index : 6
Vlaue : 6 Index : 5
Vlaue : 5 Index : 4
Vlaue : 4 Index : 3
Vlaue : 3 Index : 2
Vlaue : 2 Index : 1
Vlaue : 1 Index : 0
Vlaue : 0 Index : -1

[1, 2, 3, 4, 5, 6, 7, 8]

 */
public class Q_04 {

	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<>();
		for (int i=0;i<10;i++) {
			al.add(i);
		}
		System.out.println(al);
		
		// Using for loop
		for (int i=0;i<al.size();i++) 
			System.out.print(al.get(i)+"\t");
		System.out.println("");
		
		// Using for loop way 2
		for (int i=0;i<al.size();i++) {
			int x= al.get(i);
			System.out.print(x+"\t");
		}
		System.out.println("");
		
		// Using for loop way 3
		for (int i=0;i<al.size();i++) {
			Integer x= al.get(i);
			System.out.print(x+"\t");
			}
		System.out.println("");
		
		// Using for each loop way 1	
		for (Integer x : al) 
			System.out.print(x+"\t");
		System.out.println("");
		
		// Using for each loop way 2	
		for (int x : al) 
			System.out.print(x+"\t");
		System.out.println("");
		
		Iterator<Integer> itr =al.iterator();
		while(itr.hasNext())
			System.out.print(itr.next()+"\t");
		System.out.println("");

		Integer x=9;
		Iterator<Integer> itr2 =al.iterator();
		while(itr2.hasNext()) {
			int xx=itr2.next();
			System.out.print(xx+"\t");
			if (x.equals(xx)) {
				itr2.remove();
			}
		}
		System.out.println("");
		System.out.println(al);
		
		System.out.println("==================");
		ListIterator<Integer> ltr=al.listIterator(al.size());
		x=0;
		while (ltr.hasPrevious()) {
			int z=ltr.previous();
			System.out.println("Vlaue : "+z+" Index : "+ltr.previousIndex());
			if (x==z)
				ltr.remove();
		}
		System.out.println("");
		System.out.println(al);
	}

}
