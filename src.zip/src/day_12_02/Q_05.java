package day_12_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.ListIterator;

/*
5.There is arraylist of strings 
al { �sun� , �mon� ,�sun� , �tue� , �wed� , �mon� } 
Create another arraylist al2 which contains unique elements from al .
So al2 will be {�sun� , �mon� , �tue�, �wed� }.
 */
public class Q_05 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>(Arrays.asList("sun", "mon" ,"sun" , "tue", "wed", "mon"));
		
		ArrayList<String> al2 = new ArrayList<>();
		
		for(String x : al) {
			if(!al2.contains(x)) {
				al2.add(x);
			}
		}

		System.out.println("arraylist_1 : "+al);
		System.out.println("arraylist_2 : "+al2);
	}

}
