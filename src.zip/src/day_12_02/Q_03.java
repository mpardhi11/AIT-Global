package day_12_02;
/*
 * 3. WAP add elements to arraylist 
 * without using generics, 
 * 0th location keep Integer, 
 * 1st location String 
 * now print each element and display contents.
 ====================
 [15, Mohit]
 */
import java.util.ArrayList;

public class Q_03 {

	public static void main(String[] args) {
	ArrayList Al = new ArrayList<>();
	
	Al.add(0,new Integer(15));
	Al.add(1,"Mohit");
	
	System.out.print(Al);
	
	

	}

}
