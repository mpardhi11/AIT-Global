package day_12_02;

import java.util.ArrayList;
import java.util.Iterator;

/*
6. WAP to add 1 to 50 numbers in 
ArrayList and print only even numbers (using iterator) .
------------------------------------
Original ArrayList : [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 
						11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 
						21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 
						31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 
						41, 42, 43, 44, 45, 46, 47, 48, 49, 50]
						
print only even numbers (using iterator)
2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 	
 */
public class Q_06 {

	public static void main(String[] args) {
		ArrayList<Integer> arr_List= new ArrayList<>();

		for (int i=1;i<51;i++) {
			arr_List.add(i);
		}
		System.out.println("Original ArrayList : "+arr_List);
		
		Iterator<Integer> itr = arr_List.iterator();
		System.out.println("print only even numbers (using iterator)");
		while(itr.hasNext()) {
			Integer x=itr.next();
			if(x%2==0)
				System.out.print(x+" ");
		}
	}

}
