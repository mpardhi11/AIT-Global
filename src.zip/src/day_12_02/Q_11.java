package day_12_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/* 
11.Create arraylist of string. 
Add 7 days to list (Monday , Sunday etc) 
remove elements from list for 
which string length is more than 7.
------------------------------------
Original ArrayList : [Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday]
//==================================
Modified ArrayList : [Sunday, Monday, Tuesday, Thursday, Friday]

*/
public class Q_11 {

	public static void main(String[] args) {
		 String[] Name = {"Sunday", "Monday", "Tuesday", 
				 "Wednesday","Thursday", "Friday", "Saturday"};
		  ArrayList<String> al= new ArrayList<String>(Arrays.asList(Name));
		 // Collections.addAll(al, Name);
		 System.out.println("Original ArrayList : "+al);
		 System.out.println("//==================================");
		 for(int i=0;i<al.size();i++) {
			 if(al.get(i).length()>7)
				 al.remove(i);
		 }
		 System.out.println("Modified ArrayList : "+al);

	}

}
