package day_12_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/* 10.WAP to replace the second element of an ArrayList with the specified element. 
[Mohit, Ram, Sham, Gita, Sony]
Name to Replace at 2nd position : 
ZZZZ
[Mohit, Ram, ZZZZ, Gita, Sony]

*/
public class Q_10 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ArrayList<String> X= new ArrayList<>(Arrays.asList("Mohit", "Ram", "Sham", "Gita", "Sony"));
//		System.out.println("Eneter 5 Objects");
//		for(int i=0;i<5;i++) {
//			X.add(sc.next());
//		}

		System.out.println(X);
		System.out.println("Name to Replace at 2nd position : ");
		String replace =sc.next();
		
		X.set(2, replace);
		System.out.println(X);
		sc.close();
	}

}
