package day_12_02;

import java.util.ArrayList;
import java.util.Scanner;
/*
7.WAP to retrieve an element (at a specified index) from a given ArrayList.
 */
public class Q_07 {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		ArrayList<Integer> X= new ArrayList<>();

		for(int i=0;i<11;i++) {
			X.add(i);
		}

		System.out.println(X);
		
		System.out.println("Index Number Must < : "+X.size());
		int n =sc.nextInt();
		System.out.println(X.get(n));
		sc.close();
	}

}
