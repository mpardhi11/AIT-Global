package day_12_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/*
9.WAP to convert ArrayList to array in 2 different ways and 
array to ArrayList in 2 different ways (so total 4 ways).
-----------------------------------------------

 */
public class Q_09 {

	public static void main(String[] args) {
		 ArrayList<Integer> al= new ArrayList<>();
	        al.add(10);
	        al.add(20);
	        al.add(30);
	        al.add(40);
	        al.add(50);
	        al.add(60);
	        al.add(70);
	        al.add(80);

		 
		 System.out.println("ArrayList TO Array Method_01 : Object Array");
		 Object[] arr_01=al.toArray();
		 
		 for(Object o:arr_01) {
	        System.out.print(o+" ");
	      }
		 
		 System.out.println("");
		 System.out.println("ArrayList TO Array Method_01 : Integer Array");
	     Integer arr_02[] = new Integer[al.size()];
	     arr_02 = al.toArray(arr_02);
		 
	     for(Integer o:arr_02) {
		        System.out.print(o+" ");
		      }
		 System.out.println("");
		 System.out.println("//========================================");
		 System.out.println("");
		 System.out.println("Array TO ArrayList Method_01 : Integer Array");
		 ArrayList<Integer> arr_List_2= new ArrayList<>();

		 for (Integer o : arr_02) {
			 arr_List_2.add(o);
		 }
		 System.out.print("Method_01 : "+arr_List_2);
		 System.out.println("");

		 System.out.println("Array TO ArrayList Method_02 : Integer Array");
		 ArrayList<Integer> arr_List_3= new ArrayList<>(Arrays.asList(arr_02));
		 System.out.print("Method_02 : "+arr_List_3);
		 System.out.println("");


		 System.out.println("Array TO ArrayList Method_03 : Collections.addAll");
		 ArrayList<Integer> arr_List_4= new ArrayList<>();
		 Collections.addAll(arr_List_4, arr_02);
		 System.out.print("Method_02 : "+arr_List_4);

	}

}
