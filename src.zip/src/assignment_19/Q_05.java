package assignment_19;
/* 5. There is one thread which prints all numbers from 1 to 20 and main thread prints numbers 21 to 40. Write a program which ensures that numbers 1 to 100 are printed first.*/

class P_Print {
	synchronized void printNumbers(int n){
		   for(int i=1;i<=n;i++){  
		     System.out.println(i+" ");  
		 }  
}
}

class MyThread1 extends Thread{  
	P_Print t;  
	MyThread1(P_Print t)
	{  
	this.t=t;  
	}  
	public void run()
	{  
	t.printNumbers(20);  
	}  
  
}  
class MyThread2 extends Thread{  
		P_Print t;  
		MyThread2(P_Print t)
		{  
		this.t=t;  
		}  
		public void run()
		{  
		t.printNumbers(100);  
		}  
}  


public class Q_05 extends Thread{
	
	public static void main(String args[]) 
	{
		P_Print obj = new P_Print();
		MyThread1 t1=new MyThread1(obj);  
		MyThread2 t2=new MyThread2(obj);
		t2.setPriority(MAX_PRIORITY);
		t1.setPriority(9);
		
		t2.start();  
		t1.start();  
		
		//printNumbers();
		
		

	}
}
