package assignment_19;
/* 
4. Create a daemon thread. Show in example that JVM shuts down even if daemon thread is running.

MIN_PRIORITY of thread : 1

Setting Daemon ---> ID = [ 14 ]
Setting Daemon ---> Prority = [ 1 ]
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Processing thread
Thread.sleep(2000);
Finishing program



 */
public class Q_04_Daemon_thread {

	public static void main(String[] args) throws InterruptedException {
		Thread dt = new Thread(new DemoThread(), "dt");
		dt.setPriority(Thread.MIN_PRIORITY);
		System.out.println("MIN_PRIORITY of thread : "+dt.getPriority());
		System.out.println();
		dt.setDaemon(true);
		System.out.println("Setting Daemon ---> ID = [ "+dt.getId()+" ]");
		System.out.println("Setting Daemon ---> Prority = [ "+dt.getPriority()+" ]");
		
		
		dt.start();
		Thread.sleep(2000);
		System.out.println("Thread.sleep(2000);");
		System.out.println("Finishing program");
		
	}

}


class DemoThread implements Runnable {
	public void run() 
	{
		for(int i=0;i<19;i++) 
		{
			processSomething();
		}
	}

	void processSomething() {
			System.out.println("Processing thread");

	}

}
