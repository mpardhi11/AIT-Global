package assignment_19;
/* 1. WAP to sleep the user defined thread sleep for 10 seconds.*/

/*
Thread-0 is Under CPU 
ID pf Thread : [14] Prority of Thread [ 5 ]
Wating for 10 Sec : 
Thread 1 : i = 0
Wating for 10 Sec : 
Thread 1 : i = 1
Wating for 10 Sec : 
Thread 1 : i = 2
Wating for 10 Sec : 
Thread 1 : i = 3
Wating for 10 Sec : 
Thread 1 : i = 4


 */
class T_Thread extends Thread implements Runnable{
	int x=0;
	
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName()+" is Under CPU ");
		System.out.println("ID pf Thread : ["+Thread.currentThread().getId()+"] Prority of Thread [ "+Thread.currentThread().getPriority()+" ]");
		
		for(int i=0;i<5;i++) {
			System.out.println("Wating for 10 Sec : ");
			try {
				Thread.sleep(10_000);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("Thread 1 : i = "+i);
		}
		
	}
	
}


public class Q_01_Sleep {
public static void main(String[] args) {
	T_Thread t11= new T_Thread();
	
	t11.start();
	}
}

