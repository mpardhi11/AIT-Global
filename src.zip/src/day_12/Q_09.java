package day_12;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/*
9.WAP to convert ArrayList to array in 2 different ways and 
array to ArrayList in 2 different ways (so total 4 ways).
-----------------------------------------------

 */
public class Q_09 {

	public static void main(String[] args) {
		 ArrayList<String> al= new ArrayList<>();
		 al.add("Mohit");
		 al.add("Ram");
		 al.add("Sham");
		 al.add("Gauri");
		 al.add("Shruti");
		
		 System.out.println("Using toArray Method as object ");
		 Object[] NameList_1 =al.toArray();
		 for(Object x : NameList_1) {
			 System.out.print(x+"\t");
		 }
		 System.out.println("");
		 System.out.println("Using toArray Method as String ");
		 String [] NameList_2 = new  String [al.size()];
		 NameList_2=al.toArray(NameList_2);
		 for(String x : NameList_2) {
			 System.out.print(x+"\t");
		 }
		 System.out.println("");
		 System.out.println("Using get Method as String ");
		 String [] NameList_3 = new  String [al.size()];
		 for (int i = 0; i < al.size(); i++)
	            NameList_3[i] = al.get(i);
		 for(String x : NameList_3) {
			 System.out.print(x+"\t");
		 }

		 //========================================
		 System.out.println("");
		 System.out.println("");
		 System.out.println("");
		
		 //Method 1
		 List<String> al2= Arrays.asList(NameList_3);
	      System.out.println(al2);
		 //Method 2
	      ArrayList<String> list1 = new ArrayList<String>();
	      Collections.addAll(list1, NameList_3);
	      System.out.println(list1);

	      //Method 3
	      List<String> list2 = new ArrayList<String>();
	      for(String text:NameList_3) {
	         list2.add(text);
	      }
	      System.out.println(list2);

	}

}
