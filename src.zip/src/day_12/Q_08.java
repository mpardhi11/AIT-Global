package day_12;

import java.util.ArrayList;
import java.util.Scanner;

/*
8.WAP to insert an element into the ArrayList at the first position.
-------------------------------------
Eneter 5 elements
Mohit
Ram
Sham
Gita
Sony
[Mohit, Ram, Sham, Gita, Sony]
[Rupes, Mohit, Ram, Sham, Gita, Sony]
 */
public class Q_08 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ArrayList<String> X= new ArrayList<>();
		System.out.println("Eneter 5 Objects");
		for(int i=0;i<5;i++) {
			X.add(sc.next());
		}

		System.out.println(X);
		X.add(0, "Rupes");
		System.out.println(X);
		sc.close();
	}

}
