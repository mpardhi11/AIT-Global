package day_12;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;
/*
4. WAP to print all elements of ArrayList using -
-Iterator		-for loop		-for each
-----------------------------
10	20	500	84526	
===================
10	20	500	84526	
===================
10	20	500	84526	
===================
84526	500	20	10		
 */
public class Q_04 {

	public static void main(String[] args) {
		ArrayList<Integer> s = new ArrayList<Integer>();
		s.add(10);
		s.add(20);
		s.add(500);
		s.add(84526);
		
		for(int i=0;i<s.size();i++) {
			System.out.print(s.get(i)+"\t");;
		}
		System.out.println("");
		System.out.println("===================");
		for(Integer a : s) {
			System.out.print(a+"\t");;
		}

		System.out.println("");
		System.out.println("===================");
		 Iterator<Integer> it = s.iterator();
	        while (it.hasNext())
	 	            System.out.print(it.next() + "\t");

	     
	     System.out.println("");  
	     System.out.println("===================");

	     ListIterator<Integer> litr = s.listIterator(s.size());
	     while(litr.hasPrevious()) {
	    	 System.out.print(litr.previous()+"\t");
	    	 
	     }
	}


}
