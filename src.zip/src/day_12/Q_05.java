package day_12;

import java.util.ArrayList;
import java.util.Arrays;

/*
5.There is arraylist of strings al 
{ �sun� , �mon� ,�sun� , �tue� , �wed� , �mon� } 
Create another arraylist al2 which contains unique elements from al .
So al2 will be {�sun� , �mon� , �tue�, �wed� }.
-----------------------------------------
[sun, mon, sun, tue, wed, mon]
[]
-----------------
[sun, mon, tue, wed]
-----------------
 */
public class Q_05 {

	public static void main(String[] args) {
		ArrayList<String> WeekDays = new ArrayList<>(Arrays.asList("sun" , "mon" ,"sun" , "tue" , "wed" , "mon" ));
		ArrayList<String> WeekDays2 = new ArrayList<>();
		
		System.out.println(WeekDays);
		System.out.println(WeekDays2);
		System.out.println("-----------------");
		for(String x : WeekDays) {
			if(!WeekDays2.contains(x)) {
				WeekDays2.add(x);
			}
		}
		System.out.println(WeekDays2);
		System.out.println("-----------------");
		

	}

}
