package day_12;

import java.util.ArrayList;
import java.util.Scanner;

/* 10.WAP to replace the second element of an ArrayList with the specified element. 
Eneter 5 Objects
Mohit
Ram
Sham
Gita
Sony
[Mohit, Ram, Sham, Gita, Sony]
Name to Replace at 2nd position : 
ZZZZZZ
[Mohit, Ram, ZZZZZZ, Gita, Sony]

*/
public class Q_10 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ArrayList<String> X= new ArrayList<>();
		System.out.println("Eneter 5 Objects");
		for(int i=0;i<5;i++) {
			X.add(sc.next());
		}

		System.out.println(X);
		System.out.println("Name to Replace at 2nd position : ");
		String replace =sc.next();
		
		X.set(2, replace);
		System.out.println(X);
		sc.close();
	}

}
