package day_12;
/*
WAP add elements to arraylist without using generics, 
0th location keep Integer, 
1st location String 
now print each element and display contents.
--------------------------------------

154	Mohit	45.55	true	0	
 */
import java.util.ArrayList;
import java.util.Scanner;

public class Q_03 {
 public static void main(String[] args) {
	ArrayList data= new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	data.add(154);
	data.add("Mohit");
	data.add(45.55f);
	data.add(true);
	data.add(000);
	
	for(Object o : data ) {
		System.out.print(o+"\t");
	}
	//-----------------------
	for(int i=data.size();i<9;i++ ) {
		System.out.println("EEE");
		int x =sc.nextInt();
		data.add(i, x);
	}
	//-------------------------
	for(Object o : data ) {
		System.out.print(o+"\t");
	}
}
}
