package day_12;

import java.util.ArrayList;
import java.util.Arrays;

/* 
11.Create arraylist of string. 
Add 7 days to list (Monday , Sunday etc) 
remove elements from list for 
which string length is more than 7.
------------------------------------
[Sunday, Monday, Tuesday, Wednesday, Thursday, Friday, Saturday]
[Sunday, Monday, Tuesday, Thursday, Friday]

*/
public class Q_11 {

	public static void main(String[] args) {
		 String[] Name = {"Sunday", "Monday", "Tuesday", 
				 "Wednesday","Thursday", "Friday", "Saturday"};
		  ArrayList<String> al= new ArrayList<String>(Arrays.asList(Name));
		 System.out.println(al);
		 
		 for(int i=0;i<al.size();i++) {
			 if(al.get(i).length()>7)
				 al.remove(i);
		 }
		 System.out.println(al);

	}

}
