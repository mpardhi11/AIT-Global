package day_12;

import java.util.ArrayList;
import java.util.Scanner;

/*
12WAP to create Emp (id, name, sal) object and 
add 2objects to ArrayList. 
Print and see both variable memory space is printed. 
This is because toString 
is not overridden 
but if you would have done this for Integer 
then beautiful output would have been printed.
-----------------------------------------------------
Enter
101
500000
Mohit
Enter
102
4586541
Sham
[Emp [id=101, sal=500000, name=Mohit], Emp [id=102, sal=4586541, name=Sham]]
Emp [id=101, sal=500000, name=Mohit]
Emp [id=102, sal=4586541, name=Sham]

 */
class Emp {
	int id,sal;
	String name;
	public Emp(int id, int sal, String name) {
		//super();
		this.id = id;
		this.sal = sal;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", sal=" + sal + ", name=" + name + "]";
	}
}

public class Q_12 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		ArrayList<Object> x= new ArrayList<>();
		
		Emp[] w = new Emp[4];
		for(int i=0;i<4;i++) {
			System.out.println("Enter");
				w[i]=new Emp(sc.nextInt(),sc.nextInt(),sc.next());
			x.add(w[i]);
		}
		System.out.println("Data has been Printed---------------------");
		System.out.println(x);
		System.out.println("Data has been Printing Using Loop---------------------");
		for(int i=0;i<=1;i++) {
			System.out.println(x.get(i));
		}
		System.out.println("Searching  -----------------");
		for(int i=0;i<4;i++) {
			Emp e= (Emp) x.get(i);
			if(e.sal>10000) {
				System.out.println(e.toString());
			}
			if(e.name.equals("Sachin")) {
				System.out.println(e.toString());
			}
		}
		sc.close();
	}
}
