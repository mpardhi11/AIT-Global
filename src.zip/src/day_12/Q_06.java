package day_12;

import java.util.ArrayList;
import java.util.ListIterator;

/*
6. WAP to add 1 to 50 numbers in 
ArrayList and print only even numbers (using iterator) .
------------------------------------
===================
Size0
===================
2 4 6 8 10 
12 14 16 18 20 
22 24 26 28 30 
32 34 36 38 40 
42 44 46 48 50 

[50, 49, 48, 47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
	
 */
public class Q_06 {

	public static void main(String[] args) {
		ArrayList<Integer> X= new ArrayList<>();
		System.out.println("Size"+X.size());
		 ListIterator<Integer> it = X.listIterator();
		 
			System.out.println("===================");
			for (int i=0;i<50;i++) {
				it.add(i+1);
				if(it.hasPrevious()) {
					int z=it.previous();
					if(z%2==0) {
						System.out.print(z+" ");
						
					}
				}
			}
			System.out.println("");
			System.out.println("->>>>"+X);
	}

}
