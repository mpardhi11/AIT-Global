package day_8;

import java.util.Scanner;

/*
7. WAP to find sum of each column of a matrix.
 */
public class Q7 {
public static void main(String[] args) {
	int[][] arr1 = new int[5][5];
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter "+ arr1.length);
	for(int i=0;i<arr1.length;i++) {
		for (int j=0;j<arr1.length;j++) {
			arr1[i][j]=sc.nextInt();
		}
	}
	System.out.println("===============");
	for(int i=0;i<arr1.length;i++) {
		int sumi=0;
		for (int j=0;j<arr1.length;j++) {
			
				sumi=sumi+arr1[j][i];
				
			
		}
		System.out.println("Sum : "+sumi);
	}
	sc.close();
}
}
