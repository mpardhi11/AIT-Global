package day_8;
/*
9. WAP to print maximum in row
E.g. arr[][] ={{22, 31, 9}, {12, 25, 16}} output is - 31 and 25.
 */
/*
Enter 3
1 2 3
88 54 63
2 5 0
3
88
5

 */
import java.util.Scanner;

public class Q9 {
public static void main (String args[]) {
	int[][] arr1 = new int[3][3];
	Scanner sc =new Scanner(System.in);
	System.out.println("Enter "+ arr1.length);
	for(int i=0;i<arr1.length;i++) {
		for (int j=0;j<arr1.length;j++) {
			arr1[i][j]=sc.nextInt();
		}
	}
	//int temp=0;
	for(int i=0;i<arr1.length;i++) {
		int x =arr1[i][0];
		for (int j=0;j<arr1[i].length;j++) {
			if(x<arr1[i][j]) {
				x=arr1[i][j];
			}
		}
		System.out.println(x);
	}
	sc.close();
}
}
