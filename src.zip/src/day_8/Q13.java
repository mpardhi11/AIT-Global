package day_8;

import java.util.Scanner;

/*
13. Create array of students, student has (roll, name, age, marks). Print only
Those students who have marks more than 60 and age is less than 15.
 */

/*
Enter roll + Age + Marks + Name of 3 Sudents
01 12 61 mohit
Enter roll + Age + Marks + Name of 3 Sudents
02 16 65 Ram
Enter roll + Age + Marks + Name of 3 Sudents
03 14 89 Sham
studentsx [roll=1, age=12, marks=61, name=mohit]
studentsx [roll=3, age=14, marks=89, name=Sham]

 */
class studentsx {
	int roll,age, marks;
	String name;
	
	studentsx(int r, int a, int m, String n) {
		roll=r;
		age =a;
		marks= m;
		name =n;
	}

	@Override
	public String toString() {
		return "studentsx [roll=" + roll + ", age=" + age + ", marks=" + marks + ", name=" + name + "]";
	}
	
	
}
public class Q13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		studentsx[] S1 = new studentsx[3];
		
		for(int i=0;i<S1.length;i++) {
			System.out.println("Enter roll + Age + Marks + Name of "+S1.length+" Sudents");
			int r = sc.nextInt();
			int a = sc.nextInt();
			int m = sc.nextInt();
			String n = sc.next();
			
			S1[i]= new studentsx(r, a, m, n);
		}
		
		for (studentsx S : S1) {
			if (S.marks>60 && S.age<15) {
				System.out.println(S);
			}
		}
		sc.close();
//		if (S1.) {
//			System.out.println(Arrays.toString(S1));
//		}
	}

}
