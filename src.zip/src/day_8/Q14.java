package day_8;

import java.util.Scanner;
/*
Enter 5 Names
Ram
Mohit
Amit
Aman
Gita
Aman   Amit   Gita   Mohit   Ram   
 */
/*
14. Sort array of students in ascending order of student names.
E.g. amit must appear before robin
 */



public class Q14 {
	
public static void main(String[] args) {
	
	String[] S1 = new String[5];
	Scanner sc = new Scanner(System.in);
	
	System.out.println("Enter "+S1.length+" Names");
	for(int i=0;i<S1.length;i++) {
		S1[i]=sc.next();
	}
	
	for(int i=0;i<S1.length;i++) {
		for(int j=0;j<S1.length;j++) {
		if (S1[i].compareTo(S1[j])<0) {
			String temp= S1[i];
			S1[i]=S1[j];
			S1[j]=temp;
		}
		}
	}
	
	for (String SS :S1) {
		System.out.print(SS +"   ");
	}
	sc.close();
}
}
