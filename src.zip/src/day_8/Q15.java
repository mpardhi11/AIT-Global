package day_8;

import java.util.Scanner;

/*
15. Write Java Program to store 5 Student type objects 
in continuous memory blocks. 
Each Student will have roll, name, and marks.
a. Sort these objects in ascending order of marks, 
write a method 
sort Records in Student 
with Student type array as parameter.
b. Write show Records Method 
in Student class to show 
all records by 
using for each loop.
 */
/*
Enter Roll + Marks + Name of 5 Students
01 56 Mohit
02 84 Sham
03 99 Ram
04 51 Shruti
05 21 gauri
StuArray [roll=5, marks=21, name=gauri]
StuArray [roll=4, marks=51, name=Shruti]
StuArray [roll=1, marks=56, name=Mohit]
StuArray [roll=2, marks=84, name=Sham]
StuArray [roll=3, marks=99, name=Ram]
 */
class StuArray{
	int roll,marks;
	String name; 
	StuArray(int r, int m,String n) {
		roll=r;
		marks=m;
		name=n;
	}
	
	@Override
	public String toString() {
		return "StuArray [roll=" + roll + ", marks=" + marks + ", name=" + name + "]";
	}	
}

class Student13 {
	StuArray[] SA;
	
	public void getdata(StuArray[] SA) {
		this.SA=SA;
		
	}
	public void sort_Records () {
		for(int i=0;i<SA.length;i++) {
			StuArray[] SS=new StuArray[1];
			for(int j=0;j<SA.length;j++) {
			if(SA[i].marks<SA[j].marks) {
					SS[0]=SA[i];
					SA[i]=SA[j];
					SA[j]=SS[0];
				}
			}
		}
	}
	
	public void show_Records () {
		for(StuArray SSS : SA) {
			System.out.println(SSS);
		}
			
	}
}
public class Q15 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StuArray[] SA = new StuArray[5];
		
		System.out.println("Enter Roll + Marks + Name of "+SA.length+" Students");
		for(int i=0;i<SA.length;i++) {
			int r=sc.nextInt();
			int m = sc.nextInt();
			String n = sc.next();
			
			SA[i]= new StuArray(r, m, n);
		}
		//=================================
		Student13 S= new Student13();
		S.getdata(SA);
		//=================================
		S.sort_Records();
		S.show_Records();

	}

}
