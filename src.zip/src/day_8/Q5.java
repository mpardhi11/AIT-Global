package day_8;
/*
5. Pass a 2D array to function and access all its elements.
 */
/*
2  5  3  6  
 */
public class Q5 {

	public static void Display(int [][] a) {
		for(int i=0;i<a.length;i++) {
			for(int j=0;j<a.length;j++) {
				System.out.print(a[i][j]+"  ");
			}
		}
	}
	public static void main(String[] args) {
		int[][] a = {{2,5},{3,6}};
		
		Display(a);

	}

}


