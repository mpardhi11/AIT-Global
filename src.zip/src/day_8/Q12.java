package day_8;

import java.util.Scanner;

/*
12. WAP to print the employees from Employee[] 
array who has same salary 
(Create Employee class 
which has 3 attributes id, name, salary 
and add employee objects to your array)
 */
class Employee1 {
	int id;
	String name;
	float salary;
	public Employee1(int id, String name, float salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	
}


class employee2 {
	
}
public class Q12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		Employee1[] earr=new Employee1[4];
		Scanner  sc=new Scanner(System.in);
		for(int i=0;i<earr.length;i++)
		{
			System.out.println("enter id,name,salary");
			earr[i]=new Employee1(sc.nextInt(), sc.next(), sc.nextFloat());	
		}
		
		
		
		System.out.println("enter emp name");
		String searchname=sc.next();
		
		float sal=0;
		
		for(Employee1 ob:earr)
		{
			if(ob.name.equals(searchname))
			{
				sal=ob.salary;
				break;
			}
		}
		
		for(Employee1 ob:earr)
		{
			if(ob.salary==sal)
			{
				System.out.println(ob);
			}
		}
				
	}

}
