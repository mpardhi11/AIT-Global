package day_8;
/*
Enter ID and NAME for Student 
Enter COURSE Name and COURSE Fees: 
01 Mohit Java 51000
Enter ID and NAME for Student 
Enter COURSE Name and COURSE Fees: 
02 Ram Python 49000
Enter ID and NAME for Student 
Enter COURSE Name and COURSE Fees: 
03 Sham C++ 49500
Enter ID and NAME for Student 
Enter COURSE Name and COURSE Fees: 
04 Anjali C 56008
Enter ID and NAME for Student 
Enter COURSE Name and COURSE Fees: 
05 Shruti D++ 89000
1 Mohit Java 51000
2 Ram Python 49000
3 Sham C++ 49500
4 Anjali C 56008
5 Shruti D++ 89000
=======================================
1 Mohit Java 51000
4 Anjali C 56008
5 Shruti D++ 89000

 */
/*
01 Mohit Java 51000
02 Ram Python 49000
03 Sham C++ 49500
04 Anjali C 56008
05 Shruti D++ 89000
 */
import java.util.Scanner;

/*
3. There is Student class 
{ int id , string name ,Boolean isspecial , Course c } . 
Course {String cname , int fees } 
Assume that there is array of 10 student objects. 
Write a program to set isspecial to be true 
if course fee of that student is more than 50000. 
 */


class Student {
	int id;
	String name;
	Boolean isspecial;
	Course c;
	
	Student (int i, String n, Course cc) {
		id=i;
		name=n;
		c=cc;
	}
	}
class Course {
	String cname;
	int fees;
	Course(){}
	
	Course(String n, int f) {
		cname = n;
		fees = f;
	}
}
public class Q3 {

	public static void main(String[] args) {
		Student[] ss = new Student[5];
		Course cc =new Course ();
		
		Scanner sc = new Scanner(System.in);
		
		for (int i=0;i<ss.length;i++) {
			System.out.println("Enter ID and NAME for Student \nEnter COURSE Name and COURSE Fees: ");
			int id= sc.nextInt();
			String name= sc.next();
			String cname = sc.next();
			int fees= sc.nextInt();
			cc = new Course (cname,fees);
			ss[i]= new Student(id, name, cc);
		}
		
		
		for(Student s : ss) {
			System.out.println(s.id + " "+s.name+ " "+s.c.cname+" "+s.c.fees);
		}
		System.out.println("=======================================");
		for(Student s : ss) {
			if (s.c.fees>50_000) {
				s.isspecial=true;
				System.out.println(s.id + " "+s.name+ " "+s.c.cname+" "+s.c.fees);
			}
		}
		sc.close();
	}

}
