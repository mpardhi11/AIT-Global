                                                                             package day_8;

/*
11. Array is a two dimensional array as follows.
Arr = {{1, 2, 3, 4}, {5, 6, 7, 8}}
Create a new array ArrCopy which should be as follows
ArrCopy = {{4, 3, 2, 1} , { 8,7,6,5}}
 */
/*
4	3	2	1	
8	7	6	5	
 */
public class Q11 {

	public static void main(String[] args) {
		int[][] arr1 = {{1, 2, 3, 4}, {5, 6, 7, 8}};
		int row=2;
		int col=4;
		int[][] arr2= new int[row][col];
		int x=row-1;
		for (int i=0;i<2;i++) {
			int y=col-1;
			for(int j=0;j<4;j++) {
				arr2[i][j]=arr1[i][y];
				y--;
			}
			//x--;
		}

		for(int ax[] : arr2) {
			for(int ay: ax) {
				System.out.print(ay+"\t");
			}
		}
		
	}

}
