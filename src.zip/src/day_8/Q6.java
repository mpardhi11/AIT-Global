package day_8;

import java.util.Scanner;

/*
6. WAP to find sum of main diagonal elements of a matrix.
 */
/*
Enter 5
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
1 2 3 4 5
===============
Sum : 15

 */
public class Q6 {

	public static void main(String[] args) {
		int[][] arr1 = new int[5][5];
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter "+ arr1.length);
		for(int i=0;i<arr1.length;i++) {
			for (int j=0;j<arr1.length;j++) {
				arr1[i][j]=sc.nextInt();
			}
		}
		int sumj=0;
		System.out.println("===============");
		for(int i=0;i<arr1.length;i++) {
			for (int j=0;j<arr1.length;j++) {
				if (i==j) {
					sumj=sumj+arr1[i][j];
					
				}
			}
		}

		System.out.println("Sum : "+sumj);
		sc.close();
	}

}
