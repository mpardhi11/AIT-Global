package day_8;
/*
*/
import java.util.Scanner;

/*
4. Create an array of Theatre 
to maintain data in sorted order of Movie Rating
Theatre (Theatreid, Theatrename, location, Movie)
Movie (Movieid, Moviename, Rating).
 */
/*
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
01 4.5 JPark
01 BigMovie Pune
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
02 3.25 URI
00 RajT Munbai
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
55 4.65 Dhoom
05 TPoint Delhi
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
45 2.12 Domm2
01 Circle Pune
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
3 4.85 Movie1
94 Desk Pune
Enter Movieid, Rating and Moviename
Theatreid, Theatrename and location;
01 1.2 Movie66
9 Chai Amt

Pune 94 Desk 3 4.85
Delhi 5 TPoint 55 4.65
Pune 1 BigMovie 1 4.5
Munbai 0 RajT 2 3.25
Pune 1 Circle 45 2.12
Amt 9 Chai 1 1.2

 */
class Theatre {
	int Theatreid;
	String Theatrename,location;
	Movie M;
	
	Theatre (int Ti, String Tn, String L, Movie m) {
		Theatreid =Ti;
		Theatrename = Tn;
		location =L;
		M = m;
	}
}

class Movie {
	int Movieid;
	float Rating;
	String Moviename;
	
	Movie(int i, float r, String n){
		Movieid=i;
		Moviename=n;
		Rating=r;
	}
}
public class Q4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Theatre[] T = new Theatre[6];
		Movie m;
		
		for (int i=0;i<T.length;i++) {
			
			System.out.println("Enter Movieid, Rating and Moviename");
			System.out.println("Theatreid, Theatrename and location;");
			int Movieid= sc.nextInt();
			float Rating= sc.nextFloat();
			String Moviename= sc.next();
			int Theatreid = sc.nextInt();
			String Theatrename= sc.next();
			String location = sc.next();
			
			m = new Movie(Movieid, Rating, Moviename);
			
			T[i]= new Theatre(Theatreid, Theatrename, location, m);
		}
		
		Theatre[] T1 = new Theatre[1];
		for (int i=0;i<T.length;i++) {
			for (int j=0;j<T.length;j++) {
				if (T[i].M.Rating>T[j].M.Rating) {
					T1[0]=T[i];
					T[i]=T[j];
					T[j]=T1[0];
				}
			}
		}
sc.close();
		for(Theatre TT : T) {
			System.out.println(TT.location+" "+TT.Theatreid+" "+TT.Theatrename+" "+TT.M.Movieid+" "+TT.M.Rating);
			
		}
	}

}
