package day_8;
/*
10. WAP to print minimum in columns
E.g. arr[][]={{22, 31, 9}, {12, 5,16}, {34, 42, 2}}
Output is - 12, 5, and 2.

 */
import java.util.Scanner;

public class Q10 {

	public static void main(String[] args) {
		int[][] arr1 = new int[3][3];
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter "+ arr1.length);
		for(int i=0;i<arr1.length;i++) {
			for (int j=0;j<arr1.length;j++) {
				arr1[i][j]=sc.nextInt();
			}
		}
		//int temp=0;
		for(int i=0;i<arr1.length;i++) {
			int x =arr1[0][i];
			for (int j=0;j<arr1[i].length;j++) {
				if(x<arr1[j][i]) {
					x=arr1[j][i];
				}
			}
			System.out.print(x+"\t");
		}
		sc.close();

	}

}
