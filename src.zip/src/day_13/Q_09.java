package day_13;

import java.util.ArrayList;
import java.util.Collections;

/*
9. Consider an ArrayList of Movie [2M]
Movie has (int movieid, String moviename, List<String> actor)
Find �Amitabh bachchan has acted in how many movies
 */

public class Q_09 {

	public static void main(String[] args) {
		Q_09_01_Movie A1= new Q_09_01_Movie();
		
		ArrayList<Q_09_01_Movie> mov = new ArrayList<>();
		
		for(int i=0;i<3;i++) {
			A1.get_Movie();
			mov.add(A1);
		}
		
		for(int i=0;i<3;i++) {
			mov.get(i).AC.get(i);
		}
		

	}

}
