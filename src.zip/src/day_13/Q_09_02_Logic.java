package day_13;

import java.util.Comparator;

public class Q_09_02_Logic implements Comparator<Q_09_01_Movie>{

	@Override
	public int compare(Q_09_01_Movie o1, Q_09_01_Movie o2) {
		o1.AC.get()
		return 0;
	}

}
