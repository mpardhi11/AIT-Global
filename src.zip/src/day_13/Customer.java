package day_13;

public class Customer {
	int custId;
	long custMobile;
	String custName;
	
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custMobile=" + custMobile + ", custName=" + custName + "]";
	}

	public Customer(int custId, long custMobile, String custName) {
		super();
		this.custId = custId;
		this.custMobile = custMobile;
		this.custName = custName;
	}
	

	
}
