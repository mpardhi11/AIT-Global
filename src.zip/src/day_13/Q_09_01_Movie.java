package day_13;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Q_09_01_Movie implements Comparable<Q_09_01_Movie>{
	Scanner sc = new Scanner(System.in);
	int movieid;
	String moviename;
	int count=0;
	ArrayList<String> AC = new ArrayList<>();
	
	//Q_09_02_Acter cc;
	void get_Movie() {
		System.out.println("Id and Name");
		movieid= sc.nextInt();
		moviename = sc.next();
		System.out.println("Enter 2 Acter : ");
				for(int i=0;i<2;i++) {
					AC.add(sc.next());	
		}
	
	
	
	
	
	for(String  a: AC) {
		a.get
	}
	
	}

	
}
