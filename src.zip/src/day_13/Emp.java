package day_13;

public class Emp {
	int empid;
	String empName;
	float empSalary;
	public Emp(int empid, String empName, float empSalary) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.empSalary = empSalary;
	}

	@Override
	public String toString() {
		return "Emp [empid=" + empid + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	
	
}
