package day_13;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/*
3. Write Customer with custId,custMobile,custName . 
WAP to add elements to LinkedList which should accept 
Customer type objects only. 
Print all elements of LinkedList using -
a. Iterator
b. for loop
c. for each
----------------------------------------------------
7. Sort LinkedList created in Q3 by custId in ascending order .
-----------------------------------------
11. Sort LinkedList in Q3 by custName in ascending order,
if custNames are same then sort that objects 
further by custId in descending order.
-----------------------------------------------------------------
Enert ID , Mobile no , Name
105
4578457845
Mohit
103
789654123
Sham
101
123456789
Mohit
108
546789321
Yogi
100
012478596
Baba_ram
_________________________________________
Print elements of LinkedList using a. Iterator
_________________________________________
Customer [custId=105, custMobile=4578457845, custName=Mohit]
Customer [custId=103, custMobile=789654123, custName=Sham]
Customer [custId=101, custMobile=123456789, custName=Rohit]
Customer [custId=108, custMobile=546789321, custName=Yogi]
Customer [custId=100, custMobile=12478596, custName=Baba_ram]
_________________________________________
Print elements of LinkedList using a. for Loop
_________________________________________
Customer [custId=105, custMobile=4578457845, custName=Mohit]
Customer [custId=103, custMobile=789654123, custName=Sham]
Customer [custId=101, custMobile=123456789, custName=Rohit]
Customer [custId=108, custMobile=546789321, custName=Yogi]
Customer [custId=100, custMobile=12478596, custName=Baba_ram]
_________________________________________
Print elements of LinkedList using a. for each
_________________________________________
Customer [custId=105, custMobile=4578457845, custName=Mohit]
Customer [custId=103, custMobile=789654123, custName=Sham]
Customer [custId=101, custMobile=123456789, custName=Rohit]
Customer [custId=108, custMobile=546789321, custName=Yogi]
Customer [custId=100, custMobile=12478596, custName=Baba_ram]
_________________________________________
Sorted Using Customer ID
_________________________________________
Customer [custId=100, custMobile=12478596, custName=Baba_ram]
Customer [custId=101, custMobile=123456789, custName=Rohit]
Customer [custId=103, custMobile=789654123, custName=Sham]
Customer [custId=105, custMobile=4578457845, custName=Mohit]
Customer [custId=108, custMobile=546789321, custName=Yogi]

 */
public class Q_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		LinkedList<Customer> customers_Linked_List = new LinkedList<>();
		System.out.println("Enert ID , Mobile no , Name");
		for(int i=0;i<5;i++) {
			Customer c1=new Customer(sc.nextInt(),sc.nextLong(),sc.next());
			customers_Linked_List.add(c1);
		}
		
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. Iterator");
		System.out.println("_________________________________________");
		Iterator<Customer> itr = customers_Linked_List.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. for Loop");
		System.out.println("_________________________________________");
		for (int i=0;i<customers_Linked_List.size();i++) 
			System.out.println(customers_Linked_List.get(i));
		
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. for each");
		System.out.println("_________________________________________");
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);
		System.out.println("_________________________________________");
		System.out.println("Sorted Using Customer ID");
		System.out.println("_________________________________________");
		Collections.sort(customers_Linked_List, new Comprato());
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);
		
		
		System.out.println("_________________________________________");
		System.out.println("Sorted Using Customer ID");
		System.out.println("_________________________________________");
		Collections.sort(customers_Linked_List, new Descending_ascending());
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);
		
		
		sc.close();
	}

}
