package day_13;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

/*
6. There is ArrayList of string list1 
{ �sun� , �mon� ,�sun� , �tue� , �wed� , mon� }
Create LinkedList list2 which 
contains non-unique elements from list1. 
So list2 will be {�sun� , �mon� }.
 */
public class Q_06 {

	public static void main(String[] args) {
		ArrayList<String> Week_Days = new ArrayList<>(Arrays.asList("sun" , "mon" ,"sun" , "tue" , "wed" , "mon"));

		LinkedList<String> list2 = new LinkedList<>();
		System.out.println(Week_Days);
		Collections.sort(Week_Days);
		for(int i=1;i<Week_Days.size();i++) {
			if(Week_Days.get(i-1).compareTo(Week_Days.get(i))==0)
				list2.add(Week_Days.get(i));
		}	
		System.out.println(list2);
	
//		LinkedList<String> list3 = new LinkedList<>(Week_Days);
//
//		
//		for(String x : Week_Days) {
//			if(!list3.contains(x)) {
//				list3.add(x);
//			}
//		}
		
	}


}
