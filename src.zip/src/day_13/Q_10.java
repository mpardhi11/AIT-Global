package day_13;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/*
 10. Create ArrayList<String> and sort in descending order in different 3 ways.
 */
public class Q_10 {

	public static void main(String[] args) {
		ArrayList<String> Week_Days = new ArrayList<>(Arrays.asList("sun" , "mon" ,"sun" , "tue" , "wed" , "mon"));

		Collections.sort(Week_Days);
		System.out.println(Week_Days);
		Collections.reverse(Week_Days);
		System.out.println(Week_Days);
		Collections.sort(Week_Days,Collections.reverseOrder());
		System.out.println(Week_Days);
	}

}
