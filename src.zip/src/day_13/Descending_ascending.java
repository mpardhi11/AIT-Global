package day_13;
/*
11. Sort LinkedList in Q3 by custName in ascending order,
if custNames are same 
then sort that objects further by custId in descending order.
 */
import java.util.Comparator;

public class Descending_ascending implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		if(o1.custName.compareTo(o2.custName)>-1)
			return -1;
		else if(o1.custName.compareTo(o2.custName)<1)
			return 1;
		else if (o1.custName.compareTo(o2.custName)==0) {
			if(o1.custId>o2.custId)
				return -1;
			else if(o1.custId<o2.custId)
				return 1;
			else 
				return 0;
		}
		return 0;
	}

}
