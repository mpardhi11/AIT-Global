package day_13;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

/*
12. Create Emp class with empid,empName,empSalary. 
Create 2 ArrayList<Emp> 
say list1 and list2. 
Make a LinkedList by joining both list1 and list.
a.Sort resultant LinkedList in descending order of salary 
and if salary is same then sort it by empName, 
if empNames are also same then sort it by empId
==================================================
Enert ID , Mobile no , Name
105
Mohit
10000
104
Sham
10000
103
LLLLL
45052
102
AAAAAA
6666
101
RRRRRR
4555555
Enert ID , Mobile no , Name
106
Mohit
10000
107
Sham
10000
108
TTTTTT
15000
109
AAAAAA
16000
110
PPPPP
60000

Emp [empid=105, empName=Mohit, empSalary=10000.0]
Emp [empid=104, empName=Sham, empSalary=10000.0]
Emp [empid=103, empName=LLLLL, empSalary=45052.0]
Emp [empid=102, empName=AAAAAA, empSalary=6666.0]
Emp [empid=101, empName=RRRRRR, empSalary=4555555.0]
Emp [empid=106, empName=Mohit, empSalary=10000.0]
Emp [empid=107, empName=Sham, empSalary=10000.0]
Emp [empid=108, empName=TTTTTT, empSalary=15000.0]
Emp [empid=109, empName=AAAAAA, empSalary=16000.0]
Emp [empid=110, empName=PPPPP, empSalary=60000.0]
_________________________________________
Sorted Using Customer ID
_________________________________________
Emp [empid=101, empName=RRRRRR, empSalary=4555555.0]
Emp [empid=110, empName=PPPPP, empSalary=60000.0]
Emp [empid=103, empName=LLLLL, empSalary=45052.0]
Emp [empid=109, empName=AAAAAA, empSalary=16000.0]
Emp [empid=108, empName=TTTTTT, empSalary=15000.0]
Emp [empid=105, empName=Mohit, empSalary=10000.0]
Emp [empid=106, empName=Mohit, empSalary=10000.0]
Emp [empid=104, empName=Sham, empSalary=10000.0]
Emp [empid=107, empName=Sham, empSalary=10000.0]
Emp [empid=102, empName=AAAAAA, empSalary=6666.0]

 */
public class Q_12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		ArrayList<Emp> list1 = new ArrayList<>();
		ArrayList<Emp> list2 = new ArrayList<>();

//		System.out.println("Enert ID , Mobile no , Name");
//		for(int i=0;i<5;i++) {
//			Emp c1=new Emp(sc.nextInt(),sc.next(),sc.nextFloat());
//			list1.add(c1);
//		}
		list1.add(new Emp(1, "Mohit", 45000));
		list1.add(new Emp(2, "Sham", 22000));
		list1.add(new Emp(3, "Baburao", 54321));
		list1.add(new Emp(4, "Ram", 48515));
		list1.add(new Emp(5, "Raju", 10000));
		
		
		
		
//		System.out.println("Enert ID , Mobile no , Name");
//		for(int i=0;i<5;i++) {
//			Emp c1=new Emp(sc.nextInt(),sc.next(),sc.nextFloat());
//			list2.add(c1);
//		}
		list2.add(new Emp(11, "Mohit", 45000));
		list2.add(new Emp(22, "Sham", 22000));
		list2.add(new Emp(33, "Baburao", 54321));
		list2.add(new Emp(44, "Ram", 48515));
		list2.add(new Emp(55, "Raju", 10000));
		
		LinkedList<Emp> list3 = new LinkedList<>(list1);
		list3.addAll(list2);
		
		for(Emp cc : list3)
			System.out.println(cc);
		//-------------------------------------------
		System.out.println("_________________________________________");
		System.out.println("Sorted Using Customer ID");
		System.out.println("_________________________________________");
		//-------------------------------------------
		Collections.sort(list3, new Emp_class_Sort_Logic());
		for(Emp cc : list3)
			System.out.println(cc);
		
		sc.close();
	}

}
