package day_6;
interface X
{
void methodX();
}
//class Y implements X
//{
////void methodX()
//{
//System.out.println("Method X");
//}
//}
public class Q7 {

}
