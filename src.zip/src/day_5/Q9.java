package day_5;
/*
 * 9. 
 * --Create a class Teenager 
 * --which extends Kid created 
 * above and Implement readBook() 
 * differently in Teenager class. 
 * In main method, 
 * declare two variables k1,k2 of type Kid. 
 * Create objects of type BigKid and Teenager such that 
 * K1 should reference object of class BigKid and 
 * K2 should reference object of class Teenager, 
 * Call their respective readBook() methods.

 */

class Teenager extends Kid {
	public void readBook(String Book1) {
		System.out.println("Teenager Reading Book : "+ Book1);
	}
	
	
	
	
	
}
public class Q9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
