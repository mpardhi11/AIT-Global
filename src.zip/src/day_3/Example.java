package day_3;
/*
 * 9. Give the real time example of encapsulation with code.
 */
public class Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
