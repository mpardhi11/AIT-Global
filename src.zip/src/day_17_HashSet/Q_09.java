package day_17_HashSet;

import java.util.ArrayList;
import java.util.HashSet;

/* 
9. There is Arraylist of objects. 
All objects at even position are baller objects and 
all objects at odd position are batsman object. 

Create 2 sets such that one set contains 
all baller objects and 
another set contains all batsman objects. 
List size is always even. 
==========================================
List Size is :8
All boller objects are : 
0_Yusuf Pathan
1_Sachin Tendulkar
2_Bhuvneshwar Kumar
3_Rahul Dravid
4_Ravichandran Ashwin
5_Virat Kohli
6_Ishant Sharma
7_KL Rahul
[2_Bhuvneshwar Kumar, 6_Ishant Sharma, 4_Ravichandran Ashwin, 0_Yusuf Pathan]
[7_KL Rahul, 3_Rahul Dravid, 1_Sachin Tendulkar, 5_Virat Kohli]

*/
public class Q_09 {

	public static void main(String[] args) 
	{
		ArrayList<String> al = new ArrayList<String>();
		al.add("0_Yusuf Pathan");
		al.add("1_Sachin Tendulkar");
		al.add("2_Bhuvneshwar Kumar");
		al.add("3_Rahul Dravid");
		al.add("4_Ravichandran Ashwin");
		al.add("5_Virat Kohli");
		al.add("6_Ishant Sharma");
		al.add("7_KL Rahul");
		System.out.println("List Size is :"+al.size());
				
		HashSet<String> hs = new HashSet<String>();
		HashSet<String> hs2 = new HashSet<String>();
		System.out.println("All boller objects are : ");
		for(int i=0;i<al.size();i++)
		{
			if(i%2==0) 
			{
				hs.add(al.get(i));
				System.out.println(al.get(i));
			}
			else
			{
				hs2.add(al.get(i));
				System.out.println(al.get(i));
			}	
		}
		
		System.out.println(hs);
		System.out.println(hs2);						

}
}
