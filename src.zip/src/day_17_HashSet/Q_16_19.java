package day_17_HashSet;

import java.util.Arrays;
import java.util.TreeSet;

/* 16. WAP to get the element in a TreeSet which is greater than or equal to the given element.
17. WAP to get the element in a TreeSet which is less than or equal to the given element.
18. WAP to get the element in a TreeSet which is strictly greater than or equal to the given element.
19. WAP to get an element in a TreeSet which is strictly less than the given element.
===================================================================
[14, 15, 63, 78, 96, 100, 112]
Element is 63 : 63
Element is 63 : 63
Element is 63 : 78
Element is 78 : 63

*/
public class Q_16_19 {

	public static void main(String[] args) {
		TreeSet<Integer> ts =new TreeSet<>(Arrays.asList(14, 15,63,78,96,100, 112));
		System.out.println(ts);
		System.out.println("Element is 63 : "+ts.ceiling(63));
		System.out.println("Element is 63 : "+ts.floor(63));
		System.out.println("Element is 63 : "+ts.higher(63));
		System.out.println("Element is 78 : "+ts.lower(78));

	}

}
