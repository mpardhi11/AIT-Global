package day_17_HashSet;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NavigableSet;
import java.util.TreeSet;

/* 
10. There are 2 different arraylist , 
both contain student objects. 
But there are students present in both lists. 
Create a set which contains 
student objects from both lists. 
Ensure that no student objects are repeated. 
============================================



*/
public class Q_10 {

	public static void main(String[] args) {
		ArrayList<Student> al=new ArrayList<>();
		
		al.add(new Student(101, 151, "Mohit"));
		al.add(new Student(102, 152, "Sham"));
		al.add(new Student(103, 153, "Ram"));
		al.add(new Student(104, 154, "Gita"));
		al.add(new Student(105, 155, "Babita"));
		
		ArrayList<Student> al2=new ArrayList<>();
		
		al2.add(new Student(106, 156, "Rani"));
		al2.add(new Student(107, 157, "Nita"));
		al2.add(new Student(108, 158, "Shruti"));
		al2.add(new Student(104, 154, "Gita"));
		al2.add(new Student(105, 155, "Babita"));

		TreeSet<Student> ts=new TreeSet<>();
		ts.addAll(al2);
		ts.addAll(al);
		
		System.out.println(ts);
		System.out.println("//__________________________________");
		System.out.println("//__________________________________");
		
		System.out.println("//------Using Iterator------");
		Iterator<Student> itr=ts.iterator();
		Iterator<Student> itr2=ts.descendingIterator();
		NavigableSet<Student> ns=ts.descendingSet();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("//__________________________________");
		
		System.out.println("//------Using descendingIterator------");
		while(itr2.hasNext()) {
			System.out.println(itr2.next());
		}
		System.out.println("//__________________________________");
		
		System.out.println("//------Using descendingSet------");
		for(Student x: ns) {
			System.out.println(x);
		}
		
		
		
	}

}
