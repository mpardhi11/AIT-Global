package day_17_HashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/* 
12. There is a HashSet which has student objects. 
Create two arraylists from this hashset. 
In one arraylist called �placedStudents� 
insert all students who have been placed and 
in another arraylist �unplacedStudents�

Student class - Fields studid, Name, Qualification, yearOfpassing, placed(true/false) 
==============================================================
//------Using Iterator------
//------Using Iterator------
//------**************------
Student2 [studid=108, Name=Tushar, Qualification=BE-Mech, yearOfpassing=2018, placed=true]
Student2 [studid=110, Name=Riddhi, Qualification=MBA, yearOfpassing=2015, placed=true]
Student2 [studid=102, Name=Ram, Qualification=BE-Civil, yearOfpassing=2020, placed=true]
Student2 [studid=104, Name=Gita, Qualification=BSC, yearOfpassing=2020, placed=true]
Student2 [studid=106, Name=Raju, Qualification=BE-Mech, yearOfpassing=2020, placed=true]
//------Using Iterator------
//------**************------
Student2 [studid=109, Name=Sumit, Qualification=BSC, yearOfpassing=2020, placed=false]
Student2 [studid=101, Name=Mohit, Qualification=BCA, yearOfpassing=2021, placed=false]
Student2 [studid=105, Name=Babita, Qualification=BA, yearOfpassing=2021, placed=false]
Student2 [studid=107, Name=Baburao, Qualification=BE-Extc, yearOfpassing=2019, placed=false]
Student2 [studid=103, Name=Sham, Qualification=BE_Comp, yearOfpassing=2019, placed=false]

*/
public class Q_12 {

	public static void main(String[] args) {
		HashSet<Student2> hs=new HashSet<>();
		hs.add(new Student2(101, "Mohit", "BCA", "2021", false));
		hs.add(new Student2(102, "Ram", "BE-Civil", "2020", true));
		hs.add(new Student2(103, "Sham", "BE_Comp", "2019", false));
		hs.add(new Student2(104, "Gita", "BSC", "2020", true));
		hs.add(new Student2(105, "Babita", "BA", "2021", false));
		hs.add(new Student2(106, "Raju", "BE-Mech", "2020", true));
		hs.add(new Student2(107, "Baburao", "BE-Extc", "2019", false));
		hs.add(new Student2(108, "Tushar", "BE-Mech", "2018", true));
		hs.add(new Student2(109, "Sumit", "BSC", "2020", false));
		hs.add(new Student2(110, "Riddhi", "MBA", "2015", true));
		//--------------------------------------------------
		ArrayList<Student2> al=new ArrayList<>();
		ArrayList<Student2> al2=new ArrayList<>();
		//--------------------------------------------------
		System.out.println("//------Using Iterator------");
		Iterator<Student2> itr=hs.iterator();
		
		while(itr.hasNext()) {
			Student2 x=itr.next();
			if(x.placed) {
				al.add(x);
			}
			else
				al2.add(x);
		}

		System.out.println("//------Using Iterator------");
		System.out.println("//------**************------");
		itr=al.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("//------Using Iterator------");
		System.out.println("//------**************------");
		
		itr=al2.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		
		
	}

}
