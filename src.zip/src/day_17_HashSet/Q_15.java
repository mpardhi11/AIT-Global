package day_17_HashSet;

import java.util.LinkedHashSet;
import java.util.Set;

/* 
15. WAP wherein Set<Emp> always single 
element is present irrespective of how many Emp objects are being added
==============================================
[Emp [id=101, name=Mohit]]

*/
public class Q_15 {

	public static void main(String[] args) {
		Set<Emp> s=new LinkedHashSet<>();
		s.add(new Emp(101, "Mohit"));
		s.add(new Emp(102, "Ram"));
		s.add(new Emp(103, "Sham"));
		s.add(new Emp(104, "Roy"));
		
		System.out.println(s);

	}

}
