package day_17_HashSet;

public class Student2 {
	int studid;
	String Name, Qualification, yearOfpassing;
	boolean placed;
	public Student2(int studid, String name, String qualification, String yearOfpassing, boolean placed) {
		super();
		this.studid = studid;
		Name = name;
		Qualification = qualification;
		this.yearOfpassing = yearOfpassing;
		this.placed = placed;
	}
	@Override
	public String toString() {
		return "Student2 [studid=" + studid + ", Name=" + Name + ", Qualification=" + Qualification + ", yearOfpassing="
				+ yearOfpassing + ", placed=" + placed + "]";
	}
	
	
}
