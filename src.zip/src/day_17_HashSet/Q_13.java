package day_17_HashSet;

import java.util.Arrays;
import java.util.TreeSet;

/*
13. Consider there is already a TreeSet<Integer>created with elements. 
Write a function which will take input as a number or hardcode the number. 
If input number is present in Set then return the number 
which is present 2 locations after the matching number.
E.g. set { 14, 15,63,78,96,100, 112} . I/p 78 then return 100. 
If 100 is passed it will 
return null as there is no element 2 locations after it.
====================================================
[14, 15, 63, 78, 96, 100, 112]
100
null


*/
public class Q_13 {

	public static void main(String[] args) {
		TreeSet<Integer> ts =new TreeSet<>(Arrays.asList(14, 15,63,78,96,100, 112));
		System.out.println(ts);
		int x1=78;
		int x2=100;
		System.out.println(ts.higher(ts.higher(x1)));;		
		System.out.println(ts.higher(ts.higher(x2)));;

	}

}
