package day_17_HashSet;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//Q.03-WAP to create a HashSet from an ArrayList ?
/*
[Sandip, Manshi, Sujit, Nagesh, Komal, Tushar]
Komal
Manshi
Sandip
Nagesh
Tushar
Sujit
[Komal, Manshi, Sandip, Nagesh, Tushar, Sujit]

 */
public class Q_03 {

	public static void main(String[] args)
	{
		List<String> al = new ArrayList<String>();
		al.add("Sandip");
		al.add("Manshi");
		al.add("Sujit");
		al.add("Nagesh");
		al.add("Komal");
		al.add("Tushar");
		System.out.println(al);
		
		Set<String> s = new HashSet<String>(al);
		for(String x : s)
		{
			System.out.println(x);
		}
		System.out.println(s);
	}

}