package day_17_HashSet;
import java.util.HashSet;
//Q.08-Hashset contains string of names of 7 days of week.
//Remove �Saturday� �Sunday� from the set.
/*
[Monday, Thursday, Friday, Sunday, Wednesday, Tuesday, Saturday]
[Monday, Thursday, Friday, Wednesday, Tuesday]

 */
public class Q_08 {

		public static void main(String[] args) 
		{
			HashSet<String> hs = new HashSet<String>();
			hs.add("Monday");
			hs.add("Tuesday");
			hs.add("Wednesday");
			hs.add("Thursday");
			hs.add("Friday");
			hs.add("Saturday");
			hs.add("Sunday");
			System.out.println(hs);

			
			hs.remove("Saturday");
			hs.remove("Sunday");
			System.out.println(hs);

}
}

