package day_17_HashSet;

import java.util.Objects;

public class Student implements Comparable<Student>{
int s_ID,s_Roll;
String s_Name;
public Student(int s_ID, int s_Roll, String s_Name) {
	super();
	this.s_ID = s_ID;
	this.s_Roll = s_Roll;
	this.s_Name = s_Name;
}
@Override
public String toString() {
	return "Student [s_ID=" + s_ID + ", s_Roll=" + s_Roll + ", s_Name=" + s_Name + "]";
}
@Override
public int hashCode() {
	return Objects.hash(s_ID, s_Roll);
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Student other = (Student) obj;
	return s_ID == other.s_ID && s_Roll == other.s_Roll;
}
@Override
public int compareTo(Student o) {
	if(this.s_ID>o.s_ID)
	return 1;
	else if(this.s_ID<o.s_ID) 
		return -1;
	else
		return 0;
			
}

}
