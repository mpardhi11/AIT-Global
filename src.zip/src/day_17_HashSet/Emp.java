package day_17_HashSet;

import java.util.Objects;

public class Emp {
int id;
String name;
@Override
public String toString() {
	return "Emp [id=" + id + ", name=" + name + "]";
}
public Emp(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}
@Override
public int hashCode() {
	return 10;
}
@Override
public boolean equals(Object obj) {
//	if (this == obj)
//		return true;
//	if (obj == null)
//		return false;
//	if (getClass() != obj.getClass())
//		return false;
//	Emp other = (Emp) obj;
	return true;
}



}
