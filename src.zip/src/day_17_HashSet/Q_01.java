package day_17_HashSet;

import java.util.HashSet;
import java.util.Iterator;

/* 1. WAP to create a HashSet with Integer objects without using generics */
public class Q_01 {

	public static void main(String[] args) 
	{
		HashSet hm = new HashSet<>();
		hm.add(234);
		hm.add(156);
		hm.add(900);
		hm.add(231);
		hm.add(523);
		System.out.println(hm);
		
		Iterator itr=hm.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

}
