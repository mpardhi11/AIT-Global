package day_17_HashSet;

import java.util.LinkedHashSet;
/* 14. Convert array of Float to LinkedHashSet of Float without any Collections
readymade method such that reverse elements are stored in linkedhashset
e.g. 23.4,23.2 in array then set will have 23.2 and 23.4 
112.12
100.1
96.9
78.7
63.6
15.5
14.5
[112.12, 100.1, 96.9, 78.7, 63.6, 15.5, 14.5]

*/
public class Q_14 {

	public static void main(String[] args) {
		LinkedHashSet<Float> lhs= new LinkedHashSet<>();
		
		float[] arr= {14.5f,15.5f,63.6f,78.7f,96.9f,100.1f, 112.12f};
		
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
			lhs.add(arr[i]);
			
		}
		System.out.println(lhs);
	}

}
