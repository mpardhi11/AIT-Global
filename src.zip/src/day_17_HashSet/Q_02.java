package day_17_HashSet;


import java.util.HashSet;
import java.util.Iterator;

//Q.02-WAP to create a HashSet with some colors (String) using generics
/*
[Red, White, Pink, Yellow, Blue, Purple, Black]
Red
White
Pink
Yellow
Blue
Purple
Black

 */
public class Q_02 {

	public static void main(String[] args) 
	{
	   HashSet<String> hs = new HashSet<String>();
	   hs.add("Black");
	   hs.add("White");
	   hs.add("Red");
	   hs.add("Yellow");
	   hs.add("Pink");
	   hs.add("Blue");
	   hs.add("Purple");
	   System.out.println(hs);
	   
	   Iterator itr=hs.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}