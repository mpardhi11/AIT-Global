package day_13_02;

public class Customer implements Comparable<Customer>{
	int custId;
	long custMobile;
	String custName;
	
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custMobile=" + custMobile + ", custName=" + custName + "]";
	}

	public Customer(int custId, long custMobile, String custName) {
		super();
		this.custId = custId;
		this.custMobile = custMobile;
		this.custName = custName;
	}

	@Override
	public int compareTo(Customer o) {
		if(this.custId>o.custId)
			return 1;
		else if(this.custId<o.custId)
			return -1;
		else 
			return 0;

	}
	

	
}
