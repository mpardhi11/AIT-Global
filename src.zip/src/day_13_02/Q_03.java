package day_13_02;

import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

/*
3. Write Customer with custId,custMobile,custName . 
WAP to add elements to LinkedList which should accept 
Customer type objects only. 
Print all elements of LinkedList using -
a. Iterator
b. for loop
c. for each
----------------------------------------------------
7. Sort LinkedList created in Q3 by custId in ascending order .
-----------------------------------------
11. Sort LinkedList in Q3 by custName in ascending order,
if custNames are same then sort that objects 
further by custId in descending order.
-----------------------------------------------------------------
_________________________________________
Print elements of LinkedList using a. Iterator
_________________________________________
Customer [custId=101, custMobile=789456123, custName=Mohit]
Customer [custId=105, custMobile=485425466, custName=Sham]
Customer [custId=101, custMobile=884455147, custName=Mohit]
Customer [custId=102, custMobile=664828142, custName=Varun]
Customer [custId=108, custMobile=784513485, custName=Tarun]
Customer [custId=101, custMobile=998877665, custName=Gita]
Customer [custId=100, custMobile=884411475, custName=Sita]
Customer [custId=110, custMobile=784515789, custName=Sam]
Customer [custId=130, custMobile=335544885, custName=Sam]
Customer [custId=109, custMobile=884455147, custName=Varun]
_________________________________________
Print elements of LinkedList using a. for Loop
_________________________________________
Customer [custId=101, custMobile=789456123, custName=Mohit]
Customer [custId=105, custMobile=485425466, custName=Sham]
Customer [custId=101, custMobile=884455147, custName=Mohit]
Customer [custId=102, custMobile=664828142, custName=Varun]
Customer [custId=108, custMobile=784513485, custName=Tarun]
Customer [custId=101, custMobile=998877665, custName=Gita]
Customer [custId=100, custMobile=884411475, custName=Sita]
Customer [custId=110, custMobile=784515789, custName=Sam]
Customer [custId=130, custMobile=335544885, custName=Sam]
Customer [custId=109, custMobile=884455147, custName=Varun]
_________________________________________
Print elements of LinkedList using a. for each
_________________________________________
Customer [custId=101, custMobile=789456123, custName=Mohit]
Customer [custId=105, custMobile=485425466, custName=Sham]
Customer [custId=101, custMobile=884455147, custName=Mohit]
Customer [custId=102, custMobile=664828142, custName=Varun]
Customer [custId=108, custMobile=784513485, custName=Tarun]
Customer [custId=101, custMobile=998877665, custName=Gita]
Customer [custId=100, custMobile=884411475, custName=Sita]
Customer [custId=110, custMobile=784515789, custName=Sam]
Customer [custId=130, custMobile=335544885, custName=Sam]
Customer [custId=109, custMobile=884455147, custName=Varun]
_________________________________________
7. Sort LinkedList created in Q3 by custId in ascending order 
_________________________________________
Customer [custId=100, custMobile=884411475, custName=Sita]
Customer [custId=101, custMobile=789456123, custName=Mohit]
Customer [custId=101, custMobile=884455147, custName=Mohit]
Customer [custId=101, custMobile=998877665, custName=Gita]
Customer [custId=102, custMobile=664828142, custName=Varun]
Customer [custId=105, custMobile=485425466, custName=Sham]
Customer [custId=108, custMobile=784513485, custName=Tarun]
Customer [custId=109, custMobile=884455147, custName=Varun]
Customer [custId=110, custMobile=784515789, custName=Sam]
Customer [custId=130, custMobile=335544885, custName=Sam]
_________________________________________
11. Sort LinkedList in Q3 by custName in ascending order if custNames are same then sort that objects further by custId in descending order.
_________________________________________
Customer [custId=109, custMobile=884455147, custName=Varun]
Customer [custId=102, custMobile=664828142, custName=Varun]
Customer [custId=108, custMobile=784513485, custName=Tarun]
Customer [custId=100, custMobile=884411475, custName=Sita]
Customer [custId=105, custMobile=485425466, custName=Sham]
Customer [custId=130, custMobile=335544885, custName=Sam]
Customer [custId=110, custMobile=784515789, custName=Sam]
Customer [custId=101, custMobile=884455147, custName=Mohit]
Customer [custId=101, custMobile=789456123, custName=Mohit]
Customer [custId=101, custMobile=998877665, custName=Gita]


 */
public class Q_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		
		LinkedList<Customer> customers_Linked_List = new LinkedList<>();
//		System.out.println("Enert ID , Mobile no , Name");
//		for(int i=0;i<5;i++) {
//			Customer c1=new Customer(sc.nextInt(),sc.nextLong(),sc.next());
//			customers_Linked_List.add(c1);
//		}
		
		
		customers_Linked_List.add(new Customer(101, 789456123, "Mohit"));
		customers_Linked_List.add(new Customer(105, 485425466, "Sham"));
		customers_Linked_List.add(new Customer(101, 884455147, "Mohit"));
		customers_Linked_List.add(new Customer(102, 664828142, "Varun"));
		customers_Linked_List.add(new Customer(108, 784513485, "Tarun"));
		customers_Linked_List.add(new Customer(101, 998877665, "Gita"));
		customers_Linked_List.add(new Customer(100, 884411475, "Sita"));
		customers_Linked_List.add(new Customer(110, 784515789, "Sam"));
		customers_Linked_List.add(new Customer(130, 335544885, "Sam"));
		customers_Linked_List.add(new Customer(109, 884455147, "Varun"));

		
		
		//===============================================================
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. Iterator");
		System.out.println("_________________________________________");
		Iterator<Customer> itr = customers_Linked_List.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. for Loop");
		System.out.println("_________________________________________");
		for (int i=0;i<customers_Linked_List.size();i++) 
			System.out.println(customers_Linked_List.get(i));
		
		System.out.println("_________________________________________");
		System.out.println("Print elements of LinkedList using a. for each");
		System.out.println("_________________________________________");
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);
		System.out.println("_________________________________________");
		System.out.println("7. Sort LinkedList created in Q3 by custId in ascending order ");
		System.out.println("_________________________________________");
		Collections.sort(customers_Linked_List);
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);
		
		
		System.out.println("_________________________________________");
		System.out.println("11. Sort LinkedList in Q3 by custName in ascending order if custNames are same then sort that objects further by custId in descending order.");
		System.out.println("_________________________________________");
		Collections.sort(customers_Linked_List, new Descending_ascending());
		for(Customer cc : customers_Linked_List)
			System.out.println(cc);	
		sc.close();
	}

}
