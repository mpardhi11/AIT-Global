package day_13_02;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/* 10. Create ArrayList<String> and sort in descending order in different 3 ways. */
public class Q_10 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>(Arrays.asList("sun", "mon" ,"sun" , "tue", "wed", "mon","Mohit","Zebra"));
		
//		al.add("");
//		al.add("");
//		al.add("");
//		al.add("");
//		al.add("");
//		al.add("");
//		al.add("");
		
		Collections.sort(al, Collections.reverseOrder());
		System.out.println("Reverse Order way_1 : "+al);
		
		Collections.sort(al);
		Collections.sort(al, Collections.reverseOrder());
		System.out.println("Reverse Order way_2 : "+al);
		
		
		

	}

}
