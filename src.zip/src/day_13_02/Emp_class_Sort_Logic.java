package day_13_02;

import java.util.Comparator;

public class Emp_class_Sort_Logic implements Comparator<Emp>{

	@Override
	public int compare(Emp o1, Emp o2) {
		if(o1.empSalary>o2.empSalary)
			return -1;
		else if(o1.empSalary<o2.empSalary)
			return 1;
		else if (o1.empSalary==o2.empSalary) {
			if(o1.empName.compareTo(o2.empName)>0)
				return 1;
			else if(o1.empName.compareTo(o2.empName)<0)
				return -1;
			else if (o1.empName.compareTo(o2.empName)==0) {
				if(o1.empid>o2.empid)
					return 1;
				else if(o1.empid<o2.empid)
					return -1;
				else
					return 0;
					
			}
		}
			
		return 0;
	}

}
