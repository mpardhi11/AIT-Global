package day_13_02;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

/*
12. Create Emp class with empid,empName,empSalary. 
Create 2 ArrayList<Emp> 
say list1 and list2. 
Make a LinkedList by joining both list1 and list.
a.Sort resultant LinkedList in descending order of salary 
and if salary is same then sort it by empName, 
if empNames are also same then sort it by empId
==================================================
Emp [empid=1, empName=Mohit, empSalary=45000.0]
Emp [empid=2, empName=Sham, empSalary=22000.0]
Emp [empid=3, empName=Baburao, empSalary=54321.0]
Emp [empid=4, empName=Ram, empSalary=48515.0]
Emp [empid=5, empName=Raju, empSalary=10000.0]
Emp [empid=11, empName=Mohit, empSalary=45000.0]
Emp [empid=22, empName=Sham, empSalary=22000.0]
Emp [empid=33, empName=Baburao, empSalary=54321.0]
Emp [empid=44, empName=Ram, empSalary=48515.0]
Emp [empid=55, empName=Raju, empSalary=10000.0]
_________________________________________
a.Sort resultant LinkedList in descending order of salary 
and if salary is same then sort it by empName, 
if empNames are also same then sort it by empId
_________________________________________
Emp [empid=3, empName=Baburao, empSalary=54321.0]
Emp [empid=33, empName=Baburao, empSalary=54321.0]
Emp [empid=4, empName=Ram, empSalary=48515.0]
Emp [empid=44, empName=Ram, empSalary=48515.0]
Emp [empid=1, empName=Mohit, empSalary=45000.0]
Emp [empid=11, empName=Mohit, empSalary=45000.0]
Emp [empid=2, empName=Sham, empSalary=22000.0]
Emp [empid=22, empName=Sham, empSalary=22000.0]
Emp [empid=5, empName=Raju, empSalary=10000.0]
Emp [empid=55, empName=Raju, empSalary=10000.0]

 */
public class Q_12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		ArrayList<Emp> list1 = new ArrayList<>();
		ArrayList<Emp> list2 = new ArrayList<>();

//		System.out.println("Enert ID , Mobile no , Name");
//		for(int i=0;i<5;i++) {
//			Emp c1=new Emp(sc.nextInt(),sc.next(),sc.nextFloat());
//			list1.add(c1);
//		}
		list1.add(new Emp(1, "Mohit", 45000));
		list1.add(new Emp(2, "Sham", 22000));
		list1.add(new Emp(3, "Baburao", 54321));
		list1.add(new Emp(4, "Ram", 48515));
		list1.add(new Emp(5, "Raju", 10000));		
		
//		System.out.println("Enert ID , Mobile no , Name");
//		for(int i=0;i<5;i++) {
//			Emp c1=new Emp(sc.nextInt(),sc.next(),sc.nextFloat());
//			list2.add(c1);
//		}
		list2.add(new Emp(11, "Mohit", 45000));
		list2.add(new Emp(22, "Sham", 22000));
		list2.add(new Emp(33, "Baburao", 54321));
		list2.add(new Emp(44, "Ram", 48515));
		list2.add(new Emp(55, "Raju", 10000));
		
		LinkedList<Emp> list3 = new LinkedList<>(list1);
		list3.addAll(list2);
		
		for(Emp cc : list3)
			System.out.println(cc);
		//-------------------------------------------
		System.out.println("_________________________________________");
		System.out.println("a.Sort resultant LinkedList in descending order of salary \r\n"
				+ "and if salary is same then sort it by empName, \r\n"
				+ "if empNames are also same then sort it by empId");
		System.out.println("_________________________________________");
		//-------------------------------------------
		Collections.sort(list3, new Emp_class_Sort_Logic());
		for(Emp cc : list3)
			System.out.println(cc);
		
		sc.close();
	}

}
