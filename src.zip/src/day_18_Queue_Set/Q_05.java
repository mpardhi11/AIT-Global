package day_18_Queue_Set;

import java.util.PriorityQueue;
/*
5. What is difference between poll() and remove(). Experience it with Code.
6. What is difference between peek() and element(). Experience it with Code.
=======================================================

 */
public class Q_05 {

	public static void main(String[] args) {
		PriorityQueue<String> pq=new PriorityQueue<>();
		pq.add("Red");
//		pq.add("Yellow");
//		pq.add("Green");
//		pq.add("Blue");
//		pq.add("Purpole");
//		pq.add("SkyBlue");
		System.out.println(pq);
		System.out.println("//==================");
		System.out.println(pq.poll());
		System.out.println(pq);
		System.out.println(pq.peek());
		System.out.println(pq.element());
		System.out.println("//==================");
		System.out.println(pq.remove());
		System.out.println(pq);
		

	}

}
