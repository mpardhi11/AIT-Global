package day_18_Queue_Set;
import java.util.LinkedList;
import java.util.Queue;
import java.util.SortedSet;
import java.util.TreeSet;

/* 2. Write java code to iterate queue of numbers holding numbers in descending order. 
 * =======================================
[5, 10, 11, 20, 80, 99]
1 element -->5
2 element -->10
3 element -->11
4 element -->20
5 element -->80
6 element -->99
//==================
[]

*/
public class Q_02 {

	public static void main(String[] args) {
		
		SortedSet<Integer> ss=new TreeSet<Integer>();
		ss.add(10);
		ss.add(20);
		ss.add(80);
		ss.add(99);
		ss.add(5);
		ss.add(11);
		Queue<Integer> qq= new LinkedList<Integer>(ss);
		System.out.println(qq);
		
		Integer v;
		int x=1;
		while((v=qq.poll())!=null) {
			System.out.println(x+" element -->"+v);
			x++;
		}
		System.out.println("//==================");
		System.out.println(qq);
		

	}

}
