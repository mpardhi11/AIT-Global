package day_18_Queue_Set;

import java.util.Arrays;
import java.util.SortedSet;
import java.util.TreeSet;
/*
4. Create Sorted Set holding month names
=================================
[Apr, Aug, Dec, Feb, Jan , Jul, Jun, Mar, May, Nov, Oct, Sep]

 */
public class Q_04 {

	public static void main(String[] args) {
		SortedSet<String> ss= new TreeSet<String>(Arrays.asList("Jan ", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" ));
		
		System.out.println(ss);
	
	}
}
