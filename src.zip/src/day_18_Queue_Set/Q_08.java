package day_18_Queue_Set;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/*
8. Create Queue using LinkedList class to hold Item objects. 
One by one remove each element from queue and 
add it simultaneously in stack. 

Show the elements from queue in reverse order of their removal from queue.
===============================================================
[Item [itemid=5, itemName=Mug], Item [itemid=1, itemName=cadbary], Item [itemid=2, itemName=Pen], Item [itemid=3, itemName=Rubber], Item [itemid=4, itemName=headphone]]
Item [itemid=4, itemName=headphone]
Item [itemid=3, itemName=Rubber]
Item [itemid=2, itemName=Pen]
Item [itemid=1, itemName=cadbary]
Item [itemid=5, itemName=Mug]
Elements at : ---->  Queue
Elements at : ---->  Stack
Item [itemid=4, itemName=headphone]
Item [itemid=3, itemName=Rubber]
Item [itemid=2, itemName=Pen]
Item [itemid=1, itemName=cadbary]
Item [itemid=5, itemName=Mug]


 */
public class Q_08 {

	public static void main(String[] args) {
		Queue<Item> qq= new ArrayDeque<>();
		Stack<Item> ss= new Stack<>();
		qq.offer(new Item(5, "Mug"));
		qq.offer(new Item(1, "cadbary"));
		qq.offer(new Item(2, "Pen"));
		qq.offer(new Item(3, "Rubber"));
		qq.offer(new Item(4, "headphone"));

		System.out.println(qq);
		
		Iterator<Item> itr;
		
		for(int i=qq.size();i>0;i--) {
			System.out.println(ss.push(((ArrayDeque<Item>) qq).removeLast()));
		}
		//System.out.println(qq);
		System.out.println("Elements at : ---->  "+"Queue");
		itr=qq.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		System.out.println("Elements at : ---->  "+"Stack");
		itr=ss.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
	}

}
