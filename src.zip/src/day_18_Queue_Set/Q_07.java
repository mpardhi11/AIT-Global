package day_18_Queue_Set;

import java.util.Stack;

/*
7. Create Item class with itemid, itemName. 
Add Item objects in stack.
Display and remove each item from stack until it is empty. 
Use Stack class from collection.
================================================================================
[Item [itemid=1, itemName=cadbary], Item [itemid=2, itemName=Pen], Item [itemid=3, itemName=Rubber], Item [itemid=4, itemName=headphone]]
//---------------------------
Item [itemid=4, itemName=headphone]
Item [itemid=3, itemName=Rubber]
Item [itemid=2, itemName=Pen]
Item [itemid=1, itemName=cadbary]
//---------------------------
[]

 */
public class Q_07 {

	public static void main(String[] args) {
		Stack<Item> ss=new Stack<>();
		
		ss.push(new Item(1, "cadbary"));
		ss.push(new Item(2, "Pen"));
		ss.push(new Item(3, "Rubber"));
		ss.push(new Item(4, "headphone"));

		System.out.println(ss);
		System.out.println("//---------------------------");
		while(!ss.isEmpty()) {
			System.out.println(ss.pop());
		}
		System.out.println("//---------------------------");
		System.out.println(ss);
	}

}
