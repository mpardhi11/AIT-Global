package day_18_Queue_Set;

public class Item {
int itemid;
String itemName;
public Item(int itemid, String itemName) {
	super();
	this.itemid = itemid;
	this.itemName = itemName;
}
@Override
public String toString() {
	return "Item [itemid=" + itemid + ", itemName=" + itemName + "]";
}

}
