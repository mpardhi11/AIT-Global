package day_18_Queue_Set;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/*
9. When to use Stack and when to use Queue type implementation?
==========================================================
Input to Stack : 1,2,3,4,5 Output from stack : [1, 2, 3, 4, 5]
How Stack Works : 
5
4
3
2
1
Input to queue : 1,2,3,4,5 Output from queue : [1, 2, 3, 4, 5]
1
2
3
4
5

 */
public class Q_09 {

	public static void main(String[] args) {
		Stack<Integer> ss=new Stack<Integer>();
		ss.push(1);
		ss.push(2);
		ss.push(3);
		ss.push(4);
		ss.push(5);
		System.out.println("Input to Stack : 1,2,3,4,5"+" Output from stack : "+ss);
		System.out.println("How Stack Works : ");
		Iterator<Integer> itr=ss.iterator();
		Integer v;
		while(!ss.isEmpty()) {
			System.out.println(ss.pop());
		}
		
		
		Queue<Integer> qq=new LinkedList<Integer>();
		qq.add(1);
		qq.add(2);
		qq.add(3);
		qq.add(4);
		qq.add(5);
		System.out.println("Input to queue : 1,2,3,4,5"+" Output from queue : "+qq);
		while(!qq.isEmpty()) {
			System.out.println(qq.poll());
		}

	}

}
