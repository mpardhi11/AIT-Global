package day_18_Queue_Set;

import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.PriorityQueue;

/* 
1. Create a queue of String type colour using priority queue , add some colours and print the queue. 
3. Write a code to add queue created in Q1 in another queue.
 * ======================================================================================
[Blue, Green, Red, Yellow, Purpole, SkyBlue]
//==================
Blue
Green
Red
Yellow
Purpole
SkyBlue
//==================
Blue
Green
Red
Yellow
Purpole
SkyBlue
//==================

*/
public class Q_01 {

	public static void main(String[] args) {
		PriorityQueue<String> pq=new PriorityQueue<>();
		pq.add("Red");
		pq.add("Yellow");
		pq.add("Green");
		pq.add("Blue");
		pq.add("Purpole");
		pq.add("SkyBlue");
		System.out.println(pq);
		System.out.println("//==================");
		Iterator<String> itr=pq.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		
		System.out.println("//==================");
		for(String x : pq) {
			System.out.println(x);
		}
		System.out.println("//==================");
		
		PriorityQueue<String> pq2=new PriorityQueue<>(pq);

		System.out.println("//==================");
		for(String x : pq2) {
			System.out.println(x);
		}
	}

}
