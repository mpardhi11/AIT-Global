package day_9;

import java.util.Scanner;

/*
6. Write a Java program to convert uppercase string 
to lowercase (without using string function)

Enter String : 
MOHIT
MOHIT
mohit

 */

public class Q_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.next();
		String str2="";
		for(int i=0;i<str.length();i++) {
			char ch = str.charAt(i);
			str2+=(char) (ch+32);
		}

		System.out.println(str);
		System.out.println(str2);
		sc.close();
	}

}
