package day_9;
/*
 
 1. Create Strings with new operator and without new.
a. Create 2 string using literal and Compare string using == see same reference is there.
b. Create 2 string using new and Compare string using == see different reference is there.
 */
public class Q_01 {

	public static void main(String[] args) {
		String S1="Mohit";
		String S2= new String("Shruti");
		
		String A1="Mohit";
		String A2="Mohit";
		
		String X1= new String("Shruti");
		String X2= new String("Shruti");
		
		boolean b = (A1==A2);
		System.out.println("B : "+b);
		boolean c = (X1==X2);
		System.out.println("C : "+c);

	}

}
