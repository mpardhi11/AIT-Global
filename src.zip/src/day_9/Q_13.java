package day_9;

import java.util.Scanner;

/*
13. Write a program that takes your full name as input 
and displays the abbreviations 
of the first and middle names 
except the last name which is displayed as it is. 
For example, 
	if your name is 
			Robert Brett Roser, 
	then the output should 
			be R.B.Roser.
 */
/*
Enter :
Enter :
shriporwarmara attapattu jaisurya natwar shriramkrishna shivavenkata﻿ rajashekhara srinivasna trichipalli yekeparampir perambdur chinnaswami muttuswami venugopal iyer
s.a.j.n.s.s.r.s.t.y.p.c.m.v.iyer

Enter :
Mohit Sudhakar Pardhi
M.S.Pardhi

 */
public class Q_13 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		String str =sc.nextLine();
		String str1="";
		String[] str2=str.split(" ");
		
		if(str2.length==3) {
			for(int i=0;i<str2.length-1;i++) {
				str1+=str2[i].charAt(0)+".";
				
			}
			str1+=str2[2];
			System.out.println(str1);
		}
		//======================================================
		else if(str2.length>3) {
			str1="";
			for(int i=0;i<str2.length-1;i++) {
				str1+=str2[i].charAt(0)+".";	
			}
			for(int i=str2.length-1;i>=0;) {
				str1+=str2[i];
				break;
			}
			System.out.println(str1);
		}
		sc.close();
	}

}
