package day_9;

import java.util.Scanner;

/*
4. Write a Java program to find second occurrence of a character in a given string.
 */
/*
Enter String : 
Mohit Pardhi
Enter Char to Search :
i
second occurrence of a character 'i' in String at :location : 12
 */
public class Q_04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.nextLine();
		System.out.println("Enter Char to Search :");
		char search =sc.next().charAt(0);
		
		int x=str.indexOf(search);
		int y=str.indexOf(search, x+1);
		
		System.out.println("second occurrence of a character "
		+"'"+search+"'"+" in String at :location : "+(y+1));
	
		sc.close();
	}

}
