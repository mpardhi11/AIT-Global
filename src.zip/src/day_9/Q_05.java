package day_9;

import java.util.Scanner;

/*
5. Write a Java program to count occurrences of a word in a given string.
 */
/*
Enter String : 
red roses in red gardan with red leady
Enter String to Search :
red
occurrences fount :3 times
occurrences fount :3 times


 */
public class Q_05 {
static int occurrences(String str,String search,int ctr) {
	String[] sArr = str.split(" ");
	
	for(int i=0;i<sArr.length;i++) {
		//System.out.println(sArr[i]);
		if(search.equals(sArr[i]))
			ctr++;
	}
	
	return ctr;
}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.nextLine();
		System.out.println("Enter String to Search :");
		String search =sc.next();
		int ctr=0;
		for(int i=0;i<str.length()-1;i++) {
				i=i+str.indexOf(search, i);
				if(i!=-1)
					ctr++;
				else
					break;
		}
		
		System.out.println("occurrences fount :"+ctr+" times");
		ctr=0;
		//==========================================
		ctr=occurrences(str,search,ctr);
		System.out.println("occurrences fount :"+ctr+" times");
		sc.close();
	}

}
