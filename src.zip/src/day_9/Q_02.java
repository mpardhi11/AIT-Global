package day_9;
/*
2. Write a code to prove that strings are immutable in java?
 */

/* 
Befour Concat : Mohit
At Point of Concat : MohitPardhi
After Concat : Mohit 
*/

public class Q_02 {

	public static void main(String[] args) {
		String A1="Mohit";
		
		System.out.println("Befour Concat : "+A1);
		System.out.println("At Point of Concat : "+A1.concat("Pardhi"));
		System.out.println("After Concat : "+A1);

	}

}
