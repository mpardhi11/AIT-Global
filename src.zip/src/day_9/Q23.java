package day_9;
/*
OUTPUT

java
java programming

 */
public class Q23 {

	public static void main(String args[])
	{
	String str1 = "java";
	char arr[] = { 'j', 'a', 'v', 'a', ' ', 'p',
	'r', 'o', 'g', 'r', 'a', 'm', 'm', 'i', 'n', 'g' };
	String str2 = new String(arr);
	System.out.println(str1);
	System.out.println(str2);
	}
}
