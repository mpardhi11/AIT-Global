package day_9;

import java.util.Arrays;
import java.util.Scanner;

/*
 * 7. Write a Java program to trim leading white space characters in a string.
 * (using string function and without using string function)
 */

/*
Enter String : 
Enter String : 
      Mohhit
Mohhit
[Mohhit]
Mohhit
[Mohhit]

 */

public class Q_07 {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter String : ");
	String str = sc.next();
	
	// by using trim fun
	System.out.println(str.trim());
	
	String[] str2=str.split(" ");
	
	System.out.println(Arrays.toString(str2));
	//System.out.println(str2);
	
	String str3="";
	
	for(int i=0;i<str.length();i++) {
		if(str.charAt(i)!=32)
		{str3+=str.charAt(i);}
			
	}
	System.out.println(str3);
	String[] str4=str.split("\t");
	System.out.println(Arrays.toString(str4));
	sc.close();
}
}
