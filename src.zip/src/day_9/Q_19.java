package day_9;
/*
19. Write a function to find the substring between �is� and �of� (using string function)
String s1=�Avinash is a cricket player and he is a captain of the

Avinash is a cricket player and he is a captain of the
 a cricket player and he is a captain 
a cricket player and he is a captain
 */
public class Q_19 {

	public static void main(String[] args) {
		String S="Avinash is a cricket player and he is a captain of the";
		
		int x=S.indexOf("is");
		int y=S.lastIndexOf("of");
		String S1=S.substring((x+2), y);
		//============================
		System.out.println(S);
		System.out.println(S1);
		System.out.println(S1.trim());

	}

}
