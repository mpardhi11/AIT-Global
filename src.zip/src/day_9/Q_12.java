package day_9;

import java.util.Scanner;

/*
12. Write a Java program to replace first occurrence 
of a character with another in a string (using string function).

Enter :
MohitMohit
MohXtMohit
 */

public class Q_12 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter :");
		String str =sc.next();
		
		String str2=str.replaceFirst("i", "X");
		System.out.println(str2);
		sc.close();

	}

}
