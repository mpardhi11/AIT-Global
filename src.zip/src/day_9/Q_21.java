package day_9;

import java.util.Scanner;

/*
21. Create a User {String username, String password} 
Ask user to enter username and password. 
Find out username and password entered by user is valid or not. 
Do some validations for password entered by user 
as follows and display appropriate message to user. 
Validation Message as follows -
a. If password length is less than 8 - password must be 8 chars long.
b. If password does not contain # or @ - at least one special @ or # character must be present.
c. If password does not contain number 0 � 9 - password must contain at least one digit.
d. If password contains space - password must not have space.
e. If password does not contain uppercase char - password must have at least one uppercase letter.
f. If user enters password tQ123 - message will be password 
	must be 8 chars long. At least one special @ or # character must be present.
 */
public class Q_21 {
	static boolean isValidU_Name(String userName) {
		if(userName.length()<3) {
			System.out.println("Invalid Username");
			return false;
		}
		
		return true;
	}

	static boolean isValidPass(String pass) {
		int count=0;
		if(pass.length()<8) 
		{
			System.out.println("Password Length is less");
			for(int i=0;i<pass.length();i++) 
			{
				if((pass.charAt(i)>='a' && pass.charAt(i)<='z') && pass.charAt(i)!=32) 
				{
					count++;
				}
				else if(pass.charAt(i)>='A' && pass.charAt(i)<='A') {
					count++;
				}
				else if(pass.charAt(i)>=48 && pass.charAt(i)<=57) {
					count++;
				}
			}
		}
		System.out.println(count);
		return true;
	}
	


	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Username and Password: ");
		String str1 = sc.next();
		String str2 = sc.next();
		
		if (isValidU_Name(str1) && isValidPass(str2)) {
			System.out.println("Account Created");
		}
		else {
			System.out.println("Correct the Criditional");
		}

	}

}
