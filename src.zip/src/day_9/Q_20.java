package day_9;

import java.util.Arrays;
import java.util.Scanner;

/*
20. WAP to check if two Strings are anagrams of each other?
(Two strings are anagrams if they are written using the 
same exact letters, ignoring Space, punctuation and capitalization. 
Each letter should have the same count in both Strings 
E.g. Army and Mary is anagram of each other)
 */
/*
Enter 2 String : 
Army
Mary
With Casesencivity Strings are NOT anagrams
Without Casesencivity Strings |Army| |Mary| are anagrams
 */
public class Q_20 {
static boolean isCheck_ana(String str1,String str2) {
	//boolean b=false;
	if(str1.length()!=str2.length())
	//b=false;
	return false;
	
	char[] chArr_1=str1.toCharArray();
	char[] chArr_2=str2.toCharArray();
	Arrays.sort(chArr_1);
	Arrays.sort(chArr_2);
	
	for(int i=0;i<chArr_1.length-1;i++) {
		if(chArr_1[i]==chArr_2[i]) {
			return true;
		}		
		else
			return false;
	}
	
	return false;
}
static boolean isCheck_ana2(String str1,String str2) {
	//boolean b=false;
	if(str1.length()!=str2.length())
	//b=false;
	return false;
	
	str1=str1.toLowerCase();
	str2=str2.toLowerCase();
	char[] chArr_1=str1.toCharArray();
	char[] chArr_2=str2.toCharArray();
	Arrays.sort(chArr_1);
	Arrays.sort(chArr_2);
	//String s1= 
	if (String.valueOf(chArr_1).equals(String.valueOf(chArr_2)))
		return true;
	
	return false;
}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 2 String : ");
		String str1 = sc.next();
		String str2 = sc.next();
		
//		if(isCheck_ana(str1,str2)) {
//			System.out.println("With Casesencivity Strings |"+str1+"| |" +str2+"| are anagrams");
//		}
//		else 
//			System.out.println("With Casesencivity Strings are NOT anagrams");
//		
		if(isCheck_ana2(str1,str2)) {
			System.out.println("Without Casesencivity Strings |"+str1+"| |" +str2+"| are anagrams");
		}
		else 
			System.out.println("Without Casesencivity Strings are NOT anagrams");

	}

}
