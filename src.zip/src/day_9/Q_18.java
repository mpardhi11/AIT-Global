package day_9;
/*
18. Input a string of alphabets. 
Find out the number of occurrence 
of all alphabets in that string. 

Find out the alphabet with maximum occurrence.
 */
public class Q_18 {

	public static void main(String[] args) {
		String str="This is an umbrella abb xxxxx smallestlengthword";
		char[] sArr=str.toCharArray();
		String x="";
		for(int i=0;i<sArr.length;i++) {
			int count=0;
			for(int j=1;j<sArr.length;j++) {
				if(sArr[i]==sArr[j] && sArr[j]!='0') {
					count++;
				}
				
			}
			
			System.out.println(sArr[i]+": Comes times : "+count);
			continue;
			
		}

	}

}
