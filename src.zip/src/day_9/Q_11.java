package day_9;
/* 11. Write a Java program to find reverse of a string(using function). */
import java.util.Scanner;
/*
Enter :
Mohit
Befour Reverse : Mohit
At time of reverse: tihoM
After reverse : tihoM

 */
public class Q_11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringBuffer str=new StringBuffer();
		System.out.println("Enter :");
		str.append(sc.next());
		System.out.println("Befour Reverse : "+str);
		System.out.println("At time of reverse: "+str.reverse());
		System.out.println("After reverse : "+str);
		sc.close();
	}

}
