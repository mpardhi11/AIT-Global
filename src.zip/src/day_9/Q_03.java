package day_9;

import java.util.Scanner;

/*
3. Write a program to find the number of vowels, consonants, 
digits and white space characters in a string.
 */

/*
Enter String : 
Mohit Pardhi 123 $%1
Vowles in String : 4
Digit in String : 4
White Space in String : 3
Consonants in String : 7
Special Char in String : 2
 */
public class Q_03 {

	static void toCheck (char[] ch) {
		int vCounter=0,cCounter=0,dCounter=0,wCounter=0,sCounter=0;
/*
ASCII value of digits [0 � 9] ranges from [48 � 57]. 	
 */
		for(int i=0;i<ch.length;i++) {
			if(ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U'
					||ch[i]=='a'||ch[i]=='e'|| ch[i]=='i'||ch[i]=='o'||ch[i]=='u') 
			vCounter++;
			else if ((ch[i]>='a'&& ch[i]<='z') ||(ch[i]>='A'&& ch[i]<='Z'))
				cCounter++;
			else if (ch[i]>='0' && ch[i]<='9')
				dCounter++;
			else if (ch[i]==32)
				wCounter++;
			else 
				sCounter++;
		}	
		System.out.println("Vowles in String : "+vCounter);
		System.out.println("Digit in String : "+dCounter);
		System.out.println("White Space in String : "+wCounter);
		System.out.println("Consonants in String : "+cCounter);
		System.out.println("Special Char in String : "+sCounter);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.nextLine();
		char[] ch= str.toCharArray();
		toCheck(ch);
		sc.close();

	}

}
