package day_9;

import java.util.Scanner;

/*
8. Write a Java program to remove first and last occurrence of a word from string.
 */

/*
Enter String : 
roses red roses in red gardan with red leady
red red red
Enter word to Search :
red
 roses in red gardan with 

 */
public class Q_08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.nextLine();
		System.out.println("Enter word to Search :");
		String search =sc.next();

		int x= str.indexOf(search);
		int y= str.lastIndexOf(search);
		System.out.println(x+" "+y);
		StringBuffer sb=new StringBuffer(str);
		
		sb.replace(x, (x+search.length()+1), "");
		System.out.println(sb);
		//String str2=str.substring(x+search.length(), y);
		sb.replace(y, 10, "");
	}

}
