package day_9;

import java.util.Scanner;

/*
14. Write a program to find average of digits in string.
E.g. input string is �a5i9gfj4tabc� output: 6
 */

/*
Enter String : 
a5i9gfj4tabc
ch[i]:= 5sum := 5
ch[i]:= 9sum := 14
ch[i]:= 4sum := 18

18	3	sum2 : 162
Average : 6
 */
public class Q_14 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String : ");
		String str = sc.nextLine();
		char[] ch= str.toCharArray();
		int sum=0,sum2=0,count=0;
		for(int i=0;i<ch.length-1;i++) {
	
			if (ch[i]>='0' && ch[i]<='9')
			{
				sum+=Character.getNumericValue(ch[i]);
				sum2+=ch[i];
				count++;
				System.out.print("ch[i]:= "+ch[i]+"sum := "+sum+"\n");
			}
		}
		System.out.println("");
		System.out.println(sum+"\t"+count+"\tsum2 : "+sum2);//sum2
		System.out.println("Average : "+(sum/count));
		sc.close();
	}

}
