package day_9;

import java.util.Scanner;

/*
Special words are those words which start and end with the same letter.
Examples - EXISTENCE, COMIC, WINDOW. Palindrome words are those words 
which read the same from left to right and vice-versa. 
Examples - MALAYALAM, MADAM, LEVEL, ROTATOR,CIVIC. 
All palindromes are special words, 
but all special words are not Palindromes. 
Write a program to accept a word, 
check and print 
whether the word 
is a Palindrome or only special.
 */
public class Q22 {

	public static void main(String[] args) {
		for(int i=0;i<3;i++) {
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter a word to check : ");
			String str=sc.next();
			
			String copy="";
			for(int j=str.length()-1;j>=0;j--) {
				copy+=str.charAt(j);
			}
			//System.out.println(copy);
			if(copy.equals(str))
				System.out.println("Word : "+str+" is Palindrome");
			else
				System.out.println("Word : "+str+" is NOT Palindrome");
			
			if(str.charAt(0)==str.charAt(str.length()-1))
				System.out.println("Word : "+str+" is only special");
			else
				System.out.println("Word : "+str+" is NOT only special");
		sc.close();
		}
		
	}

}
