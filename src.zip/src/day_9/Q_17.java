package day_9;

import java.util.Arrays;

/*
17. Write a program to find out the largest 
and smallest length word in the string �This is an umbrella".
 */
/*
[This, abb, an, is, smallestlengthword, umbrella, xxxxx]
Smallest : This	Largest :xxxxx
Smallest : an	Largest :smallestlengthword
 */
public class Q_17 {

	public static void main(String[] args) {
		String str="This is an umbrella abb xxxxx smallestlengthword";
		
		String[] sArr=str.split(" ");
		
		//StringBuffer L= new StringBuffer(); //S;
		//StringBuilder S = new StringBuilder();
		Arrays.sort(sArr);
			
		System.out.println(Arrays.toString(sArr));
		System.out.println("Smallest : "+sArr[0]+"\tLargest :"+sArr[sArr.length-1]);
		
        for (int i = 0; i < sArr.length; i++) {
            for(int j=i+1;j<sArr.length;j++) {
                String tempi = sArr[i];
                String tempj = sArr[j];

                if(tempj.length()<tempi.length()) {
                	sArr[i] =sArr[j];
                	sArr[j]=tempi;
                }
            	}
        	}
		
		System.out.println("Smallest : "+sArr[0]+"\tLargest :"+sArr[sArr.length-1]);
	}
}
