package day_14;

public class Q_05 {
/* 5. Different ways to iterate over Map? */
	public static void main(String[] args) {
		// Present in Question 2

	}

}
