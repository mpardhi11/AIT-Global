package day_14;

import java.util.HashMap;
import java.util.Scanner;

/* 17. Create a hashmap which 
 * contains integer keys and String values. 
 * Take a string from user. 
 * Delete that entry in map 
 * if value matches with the input string. 
 * =======================================
Befour : {1=null, 2=Ram, 3=Alx, 4=Maxcy}
Enter String : 
Sham
After : {1=null, 2=Ram, 3=Alx, 4=Maxcy}

Befour : {1=null, 2=Ram, 3=Alx, 4=Maxcy}
Enter String : 
Alx
After : {}
*/
public class Q_17 {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		System.out.println("Befour : "+hm);		
		System.out.println("Enter String : ");
		String s=sc.next();
		
		
		//boolean b=;
		if(hm.containsValue(s))
			hm.clear();
		System.out.println("After : "+hm);

		sc.close();
	}

}
