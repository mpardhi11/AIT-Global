package day_14;

import java.util.HashMap;

/* 3. WAP to add elements to a HashMap 
 * using generics 
 * with Integer as Key and 
 * String as value. 
 * And 4 key-value entries.
 * ============================================
 * {1=null, 2=Ram, 3=Alx, 4=Maxcy}
 */
public class Q_03 {

	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		
		System.out.println(hm);

	}

}
