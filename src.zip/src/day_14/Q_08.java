package day_14;

import java.util.HashMap;

/* 
8. WAP to copy all of the mappings from the specified HashMap to another map.
=====================================================
Original HashMap :- {1=null, 2=Ram, 3=Alx, 4=Maxcy}
Hm2 Map by using Consructor(Map m ) : {1=null, 2=Ram, 3=Alx, 4=Maxcy}
Clone HashMap Using clone(); :- {1=null, 2=Ram, 3=Alx, 4=Maxcy}

 */
public class Q_08 {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		
		HashMap<Integer, String> hm2= new HashMap<>(hm);
		HashMap<Integer, String> hm3= new HashMap<>();
		hm3=(HashMap<Integer, String>) hm.clone();
		
		System.out.println("Original HashMap :- "+hm);
		System.out.println("Hm2 Map by using Consructor(Map m ) : "+hm2);
		System.out.println("Clone HashMap Using clone(); :- "+hm3);
	}

}
