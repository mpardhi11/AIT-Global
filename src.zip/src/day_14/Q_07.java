package day_14;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/* 7. WAP to get only the Values from a HashMap. 
 ======================================
Only Values are there By usig 'Colletion' :- 
null	Ram	Alx	Maxcy	
 */
public class Q_07 {

	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		
		Collection<String> collection_List=hm.values();
		Iterator<String> itr_String=collection_List.iterator();
		System.out.println("Only Values are there By usig 'Colletion' :- ");
		while(itr_String.hasNext())
			System.out.print(itr_String.next()+"\t");

	}

}
