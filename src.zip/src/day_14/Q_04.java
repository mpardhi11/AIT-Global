package day_14;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

/* 4. WAP to get all the entries from a HashMap. 
 * Iterate the entries and print the Key & Value.
 * =====================================================
Key : 1 Value :- null
Key : 2 Value :- Ram
Key : 3 Value :- Alx
Key : 4 Value :- Maxcy
 * 
 */
public class Q_04 {

	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		
		Set<Entry<Integer, String>> s1= hm.entrySet();
		Iterator<Entry<Integer, String>> itr=s1.iterator();
		
		while(itr.hasNext())
		{
			Entry e=itr.next();
			System.out.println("Key : "+e.getKey()+" Value :- "+e.getValue());
		}
	}

}
