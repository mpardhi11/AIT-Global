package day_14;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*  2. WAP to add elements to a HashMap 
without using generics (i.e. do not use <>) 
and print content of it. 
Use 
Integer as Key and 
String as Value.
 
In second HashMap add elements of 
String type as Key and 
Integer as Value.

5. Different ways to iterate over Map?


===================================================================================
___________________________
Way_1 Using Set and KeySet
___________________________
Key : 1 Value : Ravan
Key : 2 Value : Ram
Key : 3 Value : Sham
Key : 4 Value : Sita
___________________________
Way_2 Using Collection and map.values
___________________________
Only Values : Ravan
Only Values : Ram
Only Values : Sham
Only Values : Sita
___________________________
___________________________
Way_3 Using Entry Set (Entry=<K,V>)
___________________________
Key : 1 Value : Ravan
Key : 2 Value : Ram
Key : 3 Value : Sham
Key : 4 Value : Sita
___________________________
___________________________
Way_4 Using Entry Set (Entry=<K,V>) and For Loop
___________________________
Key :- 1 Values :- Ravan
Key :- 2 Values :- Ram
Key :- 3 Values :- Sham
Key :- 4 Values :- Sita
___________________________
___________________________
Way_1 Using Set and KeySet
___________________________
Key : Mohit Value : 5
Key : Sita Value : 4
Key : Sham Value : 3
Key : Ram Value : 2
___________________________
Way_2 Using Collection and map.values
___________________________
5
4
3
2
___________________________
___________________________
Way_3 Using Entry Set (Entry=<K,V>)
___________________________
Key :-Mohit Value :- 5
Key :-Sita Value :- 4
Key :-Sham Value :- 3
Key :-Ram Value :- 2
___________________________
___________________________
Way_4 Using Entry Set (Entry=<K,V>) and For Loop
___________________________
Key :- Mohit Value : 5
Key :- Sita Value : 4
Key :- Sham Value : 3
Key :- Ram Value : 2
___________________________
 */
public class Q_02 {

	public static void main(String[] args) {
		HashMap hm=new HashMap<>();
		hm.put(1, "Mohit");
		hm.put(2, "Ram");
		hm.put(3, "Sham");
		hm.put(4, "Sita");
		hm.put(1, "Ravan");
		
		//=============================
		System.out.println("___________________________");
		System.out.println("Way_1 Using Set and KeySet");
		System.out.println("___________________________");
		Set s=hm.keySet();
		Iterator itr=s.iterator();
		while(itr.hasNext()) {
			Integer key=(Integer) itr.next();
			System.out.println("Key : "+key+" Value : "+hm.get(key));
		}
		System.out.println("___________________________");
		System.out.println("Way_2 Using Collection and map.values");
		System.out.println("___________________________");
		Collection collection_Of_Values = hm.values();
		Iterator itr2=collection_Of_Values.iterator();
		
		while(itr2.hasNext())
			System.out.println("Only Values : "+itr2.next());
		System.out.println("___________________________");

		System.out.println("___________________________");	
		System.out.println("Way_3 Using Entry Set (Entry=<K,V>)");
		System.out.println("___________________________");
		Set s2=hm.entrySet();
		Iterator itr3=s2.iterator();
		while(itr3.hasNext()) {
			Map.Entry Map_Entry=(Map.Entry)itr3.next();
			System.out.println("Key : "+Map_Entry.getKey()+" Value : "+Map_Entry.getValue());
		}
		System.out.println("___________________________");

		System.out.println("___________________________");	
		System.out.println("Way_4 Using Entry Set (Entry=<K,V>) and For Loop");
		System.out.println("___________________________");
		Set<Entry<Integer,String>> s3=hm.entrySet();
		for(Entry e :s3) {
			System.out.println("Key :- "+e.getKey()+" Values :- "+e.getValue());
		}
		System.out.println("___________________________");

		//=================================================================
		HashMap hm2=new HashMap<>();
		hm2.put("Mohit",1);
		hm2.put("Ram",2);
		hm2.put("Sham",3);
		hm2.put("Sita",4);
		hm2.put("Mohit",5);

		//=================================================================
		System.out.println("___________________________");
		System.out.println("Way_1 Using Set and KeySet");
		System.out.println("___________________________");
		Set s12=hm2.keySet();
		Iterator itr12=s12.iterator();
		while(itr12.hasNext()) {
			String key2=(String) itr12.next();
			System.out.println("Key : "+key2+" Value : "+hm2.get(key2));
		}
		
		System.out.println("___________________________");
		System.out.println("Way_2 Using Collection and map.values");
		System.out.println("___________________________");
		Collection collection_Of_String = hm2.values();
		Iterator itr21=collection_Of_String.iterator();
		while(itr21.hasNext())
		System.out.println(itr21.next());
		System.out.println("___________________________");
		
		
		System.out.println("___________________________");	
		System.out.println("Way_3 Using Entry Set (Entry=<K,V>)");
		System.out.println("___________________________");
		
		Set s23=hm2.entrySet();
		Iterator itr22=s23.iterator();
		while(itr22.hasNext()) {
			Map.Entry Map_Entry_2=(Entry) itr22.next();
			System.out.println("Key :-"+Map_Entry_2.getKey()+" Value :- "+Map_Entry_2.getValue());
		}
		System.out.println("___________________________");

		System.out.println("___________________________");	
		System.out.println("Way_4 Using Entry Set (Entry=<K,V>) and For Loop");
		System.out.println("___________________________");
		Set<Entry<String,Integer>> s33=hm2.entrySet();
		for(Entry<String, Integer> e : s33) {
			System.out.println("Key :- "+e.getKey()+" Value : "+e.getValue());
		}
		System.out.println("___________________________");
		
		
		
		
	}
}
