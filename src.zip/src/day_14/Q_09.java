package day_14;

import java.util.HashMap;

/* 
9. WAP to test if a HashMap contains a mapping for the specified key.
10. WAP to test if a HashMap contains a mapping for the specified value. 
11. WAP to remove an element from HashMap using key.
=============================================
Return Boolean : true
Return Boolean : false
Return Boolean : true
Return Boolean : false
HashMap : {1=null, 2=Ram, 3=Alx, 4=Maxcy}
Key : null
HashMap : {2=Ram, 3=Alx, 4=Maxcy}
Return Boolean : true
Return Boolean : false
Return Boolean : false

*/
public class Q_09 {

	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		
		System.out.println("Return Boolean : "+hm.containsKey(04));
		System.out.println("Return Boolean : "+hm.containsKey(05));
		
		System.out.println("Return Boolean : "+hm.containsValue("Ram"));
		System.out.println("Return Boolean : "+hm.containsValue("Sham"));
		
		System.out.println("HashMap : "+hm);
		System.out.println("Key : "+hm.remove(01));
		System.out.println("HashMap : "+hm);
		System.out.println("Return Boolean : "+hm.remove(02, "Ram")); // both Condition must true
		System.out.println("Return Boolean : "+hm.remove(03, "Ram")); // both Condition must true
		System.out.println("Return Boolean : "+hm.remove(04, "Ram")); // both Condition must true
		

	}

}
