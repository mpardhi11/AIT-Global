package day_14;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

/* 6. WAP to get only the Keys from a HashMap. 
 * ========================================
Keys and Values : {1=null, 2=Ram, 3=Alx, 4=Maxcy}
only Keys :
1	2	3	4	

*/
public class Q_06 {

	public static void main(String[] args) {
		HashMap<Integer, String> hm= new HashMap<>();
		
		hm.put(01, "Mohit");
		hm.put(02, "Ram");
		hm.put(03, "Alx");
		hm.put(04, "Maxcy");
		hm.put(01, null);
		System.out.println("Keys and Values : "+hm);
		Set<Integer> s= hm.keySet();
		Iterator<Integer> itr=s.iterator();
		System.out.println("only Keys :");
		while(itr.hasNext())
			System.out.print(itr.next()+"\t");
	}

}
