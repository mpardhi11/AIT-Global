package day_14;

import java.util.ArrayList;
import java.util.HashMap;

/*
13. ArrayList Contains
al.add(�pune�);
al.add(�Mumbai�);
al.add(�pune�);
al.add(�Mumbai�);
al.add(�Nasik�);
al.add(�pune�);
create HashMap which contain String as key and Integer as value
key is name of city and value is frequency of that city;
e.g m.put(�pune�,3);
m.put(�Mumbai�,2);
Print Map using For each loop.
=============================================
HashMap : {pune=3, Nasik=1, Mumbai=2}

 */
public class Q_13 {

	public static void main(String[] args) {
		ArrayList<String> al = new ArrayList<>();
		al.add("pune");
		al.add("Mumbai");
		al.add("pune");
		al.add("Mumbai");
		al.add("Nasik");
		al.add("pune");
		
		HashMap<String, Integer> hm= new HashMap<>();		
		for(int i=0;i<al.size();i++) {
			String s=al.get(i);
			if (hm.containsKey(s)) {
				Integer x=hm.get(s);
				hm.put(s,(x+1) );
			}			
			else {
				hm.put(al.get(i), 1);
			}						
		}

		System.out.println("HashMap : "+hm);
		
}
}
