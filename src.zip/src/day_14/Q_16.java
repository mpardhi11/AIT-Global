package day_14;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/*
16. Write a program to create a hashmap as follows. 
A hashmap �oldMap� has multiple duplicate values. 

Write a program to create new hashmap �newMap� 
which contains keys as unique values of �oldMap� and 
values as count of number of times value has appeared in �map�.

e.g. oldMap = (1, �a�) , (2,�b�), (3,�c�), (4,�b�), (5,�a�), (6,�a�)
newMap = {�a�,3) , (�b�,2),(�c�,1)
=================================
{1=a, 2=b, 3=c, 4=b, 5=a, 6=a}
{a=3, b=2, c=1}
{a=3, b=2, c=1}


 */
public class Q_16 {

	public static void main(String[] args) {
		HashMap<Integer,Character> hm= new HashMap<>();		
		hm.put(1, 'a');
		hm.put(2, 'b');
		hm.put(3, 'c');
		hm.put(4, 'b');
		hm.put(5, 'a');
		hm.put(6, 'a');
		
		System.out.println(hm);
		HashMap<Character,Integer> hm2= new HashMap<>();
		//===============================================================
		Collection<Character> ch = hm.values();
		Iterator<Character> itr=ch.iterator();
		for(;itr.hasNext();) {
			Character c=itr.next();
			if(hm2.containsKey(c)) {
				hm2.put(c, (hm2.get(c)+1));
			}
			else {
				hm2.put(c, 1);
			}
		}	
		System.out.println(hm2);
		//===============================================================
		HashMap<Character,Integer> hm3= new HashMap<>();
		
		Set<Entry<Integer,Character>> set_Entery=hm.entrySet();
		Iterator<Entry<Integer, Character>> itr2=set_Entery.iterator();
		while(itr2.hasNext()) {
			Map.Entry<Integer, Character> ent=itr2.next();
			Character c=ent.getValue();
			if(hm3.containsKey(c)) {
				hm3.put(c, (hm3.get(c)+1));
			}
			else {
				hm3.put(ent.getValue(), 1);
			}			
		}
		System.out.println(hm3);
		//===============================================================



	}

}
